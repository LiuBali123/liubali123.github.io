#ifndef ARUTIL_HPP
#define ARUTIL_HPP
#include <vector>
#include <algorithm>
#include <iostream>
#include <string>
#include <iterator>

template <typename Item>
class array_util
{
public:
    explicit array_util(Item *a, size_t s) : size_(s)
    {
        items_ = a;
        vectorstored = false;
    }

    array_util(array_util &a) : size_(a.size_)
    {
        if (a.vectorstored)
        {
            vectorstored = true;
            itemsv_ = a.itemsv_;
        }
        else
        {
            vectorstored = false;
            items_ = a.items_;
        }
    }

    array_util(std::vector<Item> &v) : size_(v.size())
    {
        itemsv_ = &v;
        vectorstored = true;
    }

    bool operator==(const array_util &a) const
    {
        if (size_ != a.size_)
        {
            return false;
        }
        for (int i = 0; i < (int)size_; ++i)
        {
            if ((*this)[i] != a[i])
            {
                return false;
            }
        }
        return true;
    }

    bool equals(const array_util &a) const
    {
        return *this == a;
    }

    array_util &operator=(const array_util &a)
    {
        if (this != &a && size_ > 0 && a.size_ > 0)
        {
            for (int i = 0; i < (int)std::min(a.size_, size_); ++i)
            {
                (*this)[i] = a[i];
            }
        }
        return *this;
    }

    array_util copy(const array_util &a)
    {
        return (*this) = a;
    }

    bool permutation(const array_util &a) const
    {
        if (a.size_ != size_)
        {
            return false;
        }
        Item b[a.size_];
        Item c[size_];
        std::copy(a.items_, a.items_ + a.size_, b);
        std::copy(items_, items_ + size_, c);
        std::sort(b, b + a.size_);
        std::sort(c, c + size_);
        for (int i = 0; i < (int)size_; ++i)
        {
            if (b[i] != c[i])
            {
                return false;
            }
        }
        return true;
    }

    ~array_util()
    {
    }

    Item &operator[](size_t n)
    {
        if (vectorstored)
        {
            return itemsv_->at(n);
        }
        else
        {
            return items_[n];
        }
    }

    const Item &operator[](size_t n) const
    {
        if (vectorstored)
        {
            return itemsv_->at(n);
        }
        else
        {
            return items_[n];
        }
    }

    size_t size()
    {
        return size_;
    }

private:
    size_t size_;
    Item *items_ = nullptr;
    std::vector<Item> *itemsv_ = nullptr;
    bool vectorstored;
};

#endif