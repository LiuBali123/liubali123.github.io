package org.gyorsfalu;

import java.util.ArrayList;

/**
 * The type Budget.
 */
public class Budget {

    private static int currentMoney;
    //placeholdel valtozo amig nincsenek a zonak eltarolva, budget implementalas miatt
    private static ArrayList<Zone> placeholderZone;

    //placeholder valtozo amig incsenek a jatekos altal epitett epuletek eltarolva
    private static ArrayList<PlayerBuild> placeholderBuilding;
    /**
     * The Residental tax.
     */
    public int residentalTax=20;
    /**
     * The Industrial tax.
     */
    public int industrialTax=20;
    /**
     * The Services tax.
     */
    public int servicesTax=20;
    private static int buildingCosts=0;

    /**
     * Instantiates a new Budget.
     *
     * @param starterMoney the starter money
     */
    public Budget(int starterMoney) {
        this.currentMoney = starterMoney;
    }

    /**
     * Updates the state of the game.
     *
     * This method updates the state of the game by assigning new values to the placeholder
     * building and zone lists.
     *
     * @param zones The list of zones to be updated.
     * @param build The list of player builds to be updated.
     */
    public void updateState(ArrayList<Zone> zones, ArrayList<PlayerBuild> build){
        this.placeholderBuilding=build;
        this.placeholderZone=zones;
    }

    /**
     * Calculates the foresight of the game state.
     *
     * This method calculates the foresight of the game state by determining the building costs,
     * tax incomes, upkeep expenses, and pension expenses. It returns a formatted string with
     * the calculated values.
     *
     * @return A string containing the calculated foresight information.
     */
    public String foreSight(){
        int upkeeps=0;
        int taxincomes=0;
        int pension=0;

        for(Zone single : this.placeholderZone){
            for(Person resident : single.building.residents){
                if(resident.age<65){
                    taxincomes += residentalTax;
                    for(Zone work : this.placeholderZone){
                        if(work.building==(resident.workplace)){
                            switch (work.type) {
                                case INDUSTRIAL -> taxincomes += industrialTax;
                                case SERVICES -> taxincomes += servicesTax;
                            }
                        }
                    }
                }
            }
        }
        for(PlayerBuild building : this.placeholderBuilding){
            upkeeps-=building.upkeep;
        }
        for(Zone single : this.placeholderZone){
            for (Person resident : single.building.residents) {
                if (resident.age >= 65) {
                    pension-=resident.taxSum/20;
                }
            }
        }

        return "Building costs: "+buildingCosts+"\nTax incomes: "+ taxincomes+"\nUpkeep: "+upkeeps+"\nPension: "+pension;
    }

    /**
     * Gets current money.
     *
     * @return the current money
     */
    public static int getCurrentMoney() {
        return currentMoney;
    }

    /**
     * Sets current money.
     *
     * @param currentMoney the current money
     */
    public static void setCurrentMoney(int currentMoney) {
        Budget.currentMoney = currentMoney;
    }

    /**
     * Updates the yearly income of the game.
     *
     * This method updates the yearly income of the game by calculating the taxes collected from
     * residents and adding them to the current money. It also updates the tax sum for residents
     * who are of age 45 or older. This method should be called at the end of each year.
     */
    //minden ev vegen meg kell hivni
    public void updateYearIncome(){
        for(Zone single : this.placeholderZone){
            for(Person resident : single.building.residents){
                if(resident.age<65){
                    currentMoney += residentalTax;
                    if(resident.age>=45){
                        resident.taxSum += residentalTax;
                    }
                    for(Zone work : this.placeholderZone){
                        if(work.building==(resident.workplace)){
                            switch (work.type) {
                                case INDUSTRIAL -> {
                                    currentMoney += industrialTax;
                                    if(resident.age>=45){
                                        resident.taxSum += industrialTax;
                                    }
                                }
                                case SERVICES -> {
                                    currentMoney += servicesTax;
                                    if(resident.age>=45){
                                        resident.taxSum += servicesTax;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Updates the yearly cost of the game.
     *
     * This method updates the yearly cost of the game by subtracting the upkeep expenses of
     * player buildings and pension expenses from the current money. It should be called at the
     * end of each year.
     */
    //minden ev vegen meg kell hivni
    public void updateYearCost(){
        for(PlayerBuild building : this.placeholderBuilding){
            currentMoney-=building.upkeep;
        }
        for(Zone single : this.placeholderZone){
            for (Person resident : single.building.residents) {
                if (resident.age >= 65) {
                    currentMoney-=resident.taxSum/20;
                }
            }

        }
    }

    /**
     * Calculates the build cost for a player building.
     *
     * This method calculates the build cost for a player building by subtracting the building's price
     * from the current money and adding the price to the total building costs.
     *
     * @param building The player building for which the build cost is calculated.
     */
    public static void buildCost(PlayerBuild building) {
        currentMoney -= building.price;
        buildingCosts+=building.price;

    }

    /**
     * Calculates the money gained from demolishing a player building.
     *
     * This method calculates the money gained from demolishing a player building by adding 80% of
     * the building's price to the current money.
     *
     * @param building The player building to be demolished.
     */
    public static void demolishMoney(PlayerBuild building) {
        currentMoney += building.price * 0.8;
    }

    /**
     * Checks if the player is bankrupt.
     *
     * This method checks if the player is bankrupt by evaluating if the current money is less than
     * -50000. If the player's current money is below this threshold, it returns true, indicating that
     * the player is bankrupt. Otherwise, it returns false.
     *
     * @return true if the player is bankrupt, false otherwise.
     */
    public boolean isBankrupt() {
        return currentMoney < -50000;
    }


}
