package org.gyorsfalu;

import java.awt.*;
import java.util.ArrayList;

/**
 * The type Building.
 */
public class Building {
    /**
     * The P.
     */
    Point p;
    /**
     * The Level.
     */
    int level;
    /**
     * The Max capacity.
     */
    int maxCapacity;
    /**
     * The Satisfaction.
     */
    double satisfaction;
    /**
     * The Residents.
     */
    ArrayList<Person> residents;
    /**
     * The Progress.
     */
    int progress = 1;
    /**
     * The Is safe.
     */
    Boolean isSafe;
    /**
     * The Safe num.
     */
    int safeNum;
    /**
     * The Zone.
     */
    Zone zone;

    /**
     * Instantiates a new Building.
     *
     * This constructor creates a new Building object with the specified position and associated zone.
     * It initializes the level to 0, satisfaction to 50, maxCapacity to 0, and creates an empty
     * residents list. The isSafe flag is set to false and the safeNum is set to 0.
     *
     * @param p    The position of the building.
     * @param zone The associated zone of the building.
     */
    Building(Point p, Zone zone) {
        this.p = p;
        this.zone = zone;
        this.level = 0;
        this.satisfaction = 50;
        this.maxCapacity = 0;
        this.residents = new ArrayList<>();
        this.isSafe = false;
        this.safeNum = 0;

    }


    /**
     * Counts the number of residents in the building.
     *
     * This method counts the number of residents currently residing in the building and returns the count
     * as an integer value.
     *
     * @return The number of residents in the building.
     */
    public int countResidents() {
        return residents.size();
    }

    /**
     * Adds a person to the building.
     *
     * This method adds the specified person to the list of residents in the building.
     *
     * @param p The person to be added.
     */
    public void addPerson(Person p) {
        this.residents.add(p);
    }


    /**
     * Checks if there is space for more residents.
     *
     * @return true if there is space for more residents, false otherwise.
     */
    public boolean isThereSpace(){
        return this.residents.size() < maxCapacity;
    }

    /**
     * Calculates the overall satisfaction of the building.
     *
     * @return The calculated overall satisfaction of the building.
     */
    public double calcSatisfaction() {
        double sum = 0;
        for (Person p : residents) {
            sum += p.getSatisfaction();
        }
        if (countResidents() == 0) {
            this.satisfaction = 0;
            return 0;
        }
        this.satisfaction = sum / countResidents();
        return sum / countResidents();
    }

    /**
     * Handles the safety status of the building.
     *
     * @param safety The safety status of the building.
     */
    public void handleSafety(Boolean safety){
        if(safety){
            this.isSafe = true;
            ++this.safeNum;
        }else{
            if(this.safeNum > 0){
                --this.safeNum;
            }
            if(this.safeNum == 0){
                this.isSafe = false;
            }
        }
    }

    /**
     * Influences the satisfaction of residents in the building.
     *
     * @param effect The amount of influence on residents' satisfaction.
     */
    public void influenceSat(int effect){
        for (Person p : residents) {
            p.influenceSat(effect);
        }
        calcSatisfaction();
    }


    /**
     * Remove person.
     *
     * @param p the p
     */
    public void removePerson(Person p) {
        residents.remove(p);
    }
}
