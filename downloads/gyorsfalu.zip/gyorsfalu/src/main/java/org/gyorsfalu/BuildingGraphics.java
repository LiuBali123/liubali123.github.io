package org.gyorsfalu;

import java.awt.*;

/**
 * The type Building graphics.
 */
public abstract class BuildingGraphics {
    /**
     * The Tiles.
     */
    BuildingGraphics[][] tiles;
    /**
     * The Image.
     */
    Image image;
    /**
     * The Current time.
     */
    int currentTime;
    /**
     * The Created.
     */
    int created;

    /**
     * Draws the building.
     *
     * @param grphcs The graphics object used for drawing.
     * @param point  The position to draw the building.
     */
    //draws the building and shows if it is being hovered
    public void draw(Graphics grphcs, Point point) {
        grphcs.drawImage(image, point.x * GamePanel.PIXEL_SIZE, point.y * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, null);
    }

    /**
     * Demolish.
     *
     * @param coord the coord
     * @param map   the map
     */
    public void demolish (Point coord, Map map){}

    /**
     * Updates the time and tiles for the building.
     *
     * @param currentTime The current time.
     * @param tiles       The tiles containing building graphics.
     */
    public void updateTime(int currentTime, BuildingGraphics[][] tiles) {
        this.currentTime = currentTime;
        this.tiles = tiles;
        onUpdateTime();
    }

    /**
     * On update time.
     */
    public void onUpdateTime() {}
}
