package org.gyorsfalu;

/**
 * The enum Building type.
 */
public enum BuildingType {
    /**
     * Empty building type.
     */
    EMPTY,
    /**
     * Grass building type.
     */
    GRASS,
    /**
     * Road building type.
     */
    ROAD,
    /**
     * Residential building type.
     */
    RESIDENTIAL,
    /**
     * Industrial building type.
     */
    INDUSTRIAL,
    /**
     * Services building type.
     */
    SERVICES,
    /**
     * Fire building type.
     */
    FIRE,
    /**
     * Police building type.
     */
    POLICE,
    /**
     * Stadium building type.
     */
    STADIUM,
    /**
     * Forest building type.
     */
    FOREST,
    /**
     * Onfire building type.
     */
    ONFIRE
}
