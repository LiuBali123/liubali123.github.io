package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.*;

/**
 * The type Fire station.
 */
public class FireStation extends PlayerBuild {
    /**
     * The Fire man id.
     */
    int fireManId;
    /**
     * The Is fireman moving.
     */
    boolean isFiremanMoving = false;

    /**
     * Instantiates a new Fire station.
     *
     * @param p The position of the fire station.
     */
    FireStation(Point p) {
        super(p);
        fireManId = new Random().nextInt(99999);
        isFlammable = false;
        this.price = 200;
        this.upkeep = 150;
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/fire.png").getImage();//PLACEHOLDER PIC
        this.radius = 6;
        this.effect = 5;
    }

    /**
     * Moves the fireman to a target location on the map.
     *
     * This method calculates the shortest path for the fireman to reach the target location on the map.
     * It uses a modified version of Dijkstra's algorithm to find the path through road tiles.
     *
     * @param map     The map object representing the game map.
     * @param targetP The target position to move the fireman to.
     * @param startP  The starting position of the fireman. If null, the nearest road tile will be chosen as the starting point.
     */
    public void moveFireMan(Map map, Point targetP, Point startP) {
        if (!map.tiles[targetP.x][targetP.y].getClass().equals(Road.class)) {
            return;
        }
        if (isFiremanMoving) {
            return;
        }
        if (startP == null) {
            for (Fireman fireman : map.fireManLocation) {
                if (fireman.id == fireManId) {
                    return;
                }
            }
        }

        BuildingGraphics[][] tiles = map.tiles;
        int rows = tiles.length;
        int cols = tiles[0].length;
        boolean[][] visited = new boolean[rows][cols];
        int[][] distances = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            Arrays.fill(distances[i], Integer.MAX_VALUE);
        }
        distances[targetP.x][targetP.y] = 0;
        PriorityQueue<Point> queue = new PriorityQueue<>(Comparator.comparingInt(a -> distances[a.x][a.y]));
        queue.offer(targetP);
        while (!queue.isEmpty()) {
            Point curr = queue.poll();
            if (tiles[curr.x][curr.y].getClass().equals(Road.class)) {
                if (visited[curr.x][curr.y]) {
                    continue;
                }
                visited[curr.x][curr.y] = true;
                int dist = distances[curr.x][curr.y];
                for (Point neighbor : getNeighbors(curr, rows, cols)) {
                    if (tiles[neighbor.x][neighbor.y].getClass().equals(Road.class)) {
                        int newDist = dist + getDistance(curr, neighbor);
                        if (newDist < distances[neighbor.x][neighbor.y]) {
                            distances[neighbor.x][neighbor.y] = newDist;
                            queue.offer(neighbor);
                        }
                    }
                }
            }
        }
        boolean goFromStation = false;
        if (startP == null) {
            goFromStation = true;
            startP = getRoadNeighbor(tiles);
        }
        ArrayList<Point> path = backtrack(distances, targetP, startP);
        if (path == null) {
            return;
        }
        Timer timer = new Timer();
        isFiremanMoving = true;
        timer.scheduleAtFixedRate(new FiremanStepper(goFromStation, path, timer, map, this), 0, 1000);
    }

    /**
     * Returns the neighboring points of a given point within the specified grid dimensions.
     *
     * @param p The point for which neighbors are to be found.
     * @param rows The number of rows in the grid.
     * @param cols The number of columns in the grid.
     * @return An ArrayList containing the neighboring points of the given point.
     */
    private ArrayList<Point> getNeighbors(Point p, int rows, int cols) {
        ArrayList<Point> neighbors = new ArrayList<>();
        if (p.x > 0) {
            neighbors.add(new Point(p.x - 1, p.y));
        }
        if (p.x < rows - 1) {
            neighbors.add(new Point(p.x + 1, p.y));
        }
        if (p.y > 0) {
            neighbors.add(new Point(p.x, p.y - 1));
        }
        if (p.y < cols - 1) {
            neighbors.add(new Point(p.x, p.y + 1));
        }
        return neighbors;
    }

    /**
     * Gets a neighboring road tile from the given map tiles.
     *
     * This method searches for a neighboring road tile based on the current coordinate.
     * It checks the surrounding tiles in the cardinal directions (up, down, left, right)
     * and returns the coordinates of the first road tile found.
     *
     * @param tiles The map tiles representing the game map.
     * @return The coordinates of the neighboring road tile, or the current coordinate if no road tile is found.
     */
    public Point getRoadNeighbor(BuildingGraphics[][] tiles) {
        if (coordinate.x > 0) {
            if (tiles[coordinate.x - 1][coordinate.y].getClass().equals(Road.class)) {
                return new Point(coordinate.x - 1, coordinate.y);
            }
        }
        if (coordinate.x < tiles.length - 1) {
            if (tiles[coordinate.x + 1][coordinate.y].getClass().equals(Road.class)) {
                return new Point(coordinate.x + 1, coordinate.y);
            }
        }
        if (coordinate.y > 0) {
            if (tiles[coordinate.x][coordinate.y - 1].getClass().equals(Road.class)) {
                return new Point(coordinate.x, coordinate.y - 1);
            }
        }
        return new Point(coordinate.x, coordinate.y + 1);
    }

    /**
     * Calculates the Manhattan distance between two points.
     * @param a The first point.
     * @param b The second point.
     * @return The Manhattan distance between the two points.
     */
    private int getDistance(Point a, Point b) {
        int dx = a.x - b.x;
        int dy = a.y - b.y;
        return Math.abs(dx) + Math.abs(dy);
    }

    /**
     * Backtracks the shortest path from the target to the start point based on the distances array.
     * @param distances The 2D array representing the distances between points.
     * @param start The start point of the path.
     * @param target The target point of the path.
     * @return An ArrayList of points representing the shortest path from the target to the start point.
     */
    private ArrayList<Point> backtrack(int[][] distances, Point start, Point target) {
        ArrayList<Point> path = new ArrayList<>();
        Point curr = target;
        if (distances[target.x][target.y] == Integer.MAX_VALUE) {
            return null;
        }
        while (!curr.equals(start)) {
            path.add(curr);
            int dist = distances[curr.x][curr.y];
            for (Point neighbor : getNeighbors(curr, distances.length, distances[0].length)) {
                if (distances[neighbor.x][neighbor.y] == dist - getDistance(curr, neighbor)) {
                    curr = neighbor;
                    break;
                }
            }
        }
        path.add(start);
        return path;
    }


    /**
     * The type Fireman stepper.
     */
    public class FiremanStepper extends TimerTask {
        /**
         * The Go from station.
         */
        boolean goFromStation;
        /**
         * The Path.
         */
        ArrayList<Point> path;
        /**
         * The Timer.
         */
        Timer timer;
        /**
         * The Map.
         */
        Map map;
        /**
         * The Fire station.
         */
        FireStation fireStation;

        /**
         * Instantiates a new Fireman stepper.
         *
         * @param goFromStation the go from station
         * @param path          the path
         * @param timer         the timer
         * @param map           the map
         * @param fireStation   the fire station
         */
        public FiremanStepper(boolean goFromStation, ArrayList<Point> path, Timer timer, Map map, FireStation fireStation) {
            this.goFromStation = goFromStation;
            this.path = path;
            this.timer = timer;
            this.map = map;
            this.fireStation = fireStation;
        }

        /**
         * Runs the movement of the fireman.
         * If the path is empty, the timer is cancelled, and the fireman's moving state is set to false.
         * If the fireman is not moving from the fire station and its current location matches the road neighbor,
         * it is removed from the list of fireman locations.
         * The current position of the fireman is updated in the list of fireman locations.
         * the first point is removed from the path.
         */
        @Override
        public void run() {
            assert path != null;
            if (path.size() == 0) {
                timer.cancel();
                fireStation.isFiremanMoving = false;
                if (!goFromStation) {
                    for (Fireman fireman : map.fireManLocation) {
                        if (fireman.id == fireManId) {
                            if (!goFromStation && fireman.location.equals(getRoadNeighbor(tiles))) {
                                map.fireManLocation.remove(fireman);
                                return;
                            }
                        }
                    }
                }
                return;
            }
            Point currentPos = path.get(0);
            boolean found = false;
            for (Fireman fireman : map.fireManLocation) {
                if (fireman.id == fireManId) {
                    found = true;
                    fireman.location = currentPos;
                }
            }
            if (!found) {
                map.fireManLocation.add(new Fireman(fireManId, currentPos));
            }
            path.remove(0);
        }
    }

}
