package org.gyorsfalu;

import java.awt.*;

/**
 * The type Fireman.
 */
public class Fireman {
    /**
     * The Id.
     */
    int id;
    /**
     * The Location.
     */
    Point location;

    /**
     * Instantiates a new Fireman.
     *
     * @param id       The ID of the fireman.
     * @param location The location of the fireman.
     */
    public Fireman(int id, Point location) {
        this.id = id;
        this.location = location;
    }
}
