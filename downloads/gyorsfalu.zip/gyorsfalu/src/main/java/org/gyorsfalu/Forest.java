package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * The type Forest.
 */
public class Forest extends PlayerBuild{

    /**
     * The Influenced.
     */
    ArrayList<Point> influenced; // 0. - bal, 1. - fent, 2. - jobb, 3. - lent
    /**
     * The Is grown.
     */
    Boolean isGrown;

    /**
     * Instantiates a new Forest object.
     *
     * @param p The initial position of the Forest.
     */
    Forest(Point p){
        super(p);
        this.radius = 3;
        this.price = 10;
        this.upkeep = 5;
        this.effect = 10;
        this.isFlammable = false;
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/forest.png").getImage();
        this.influenced = new ArrayList<>();
        for(int i = 0; i < 4; ++i){
            this.influenced.add(i,p);
        }
        this.isGrown = false;
    }

    /**
     * Checks if a given point is placeable on the map.
     *
     * @param p The point to check.
     * @param map The map object.
     * @return true if the point is placeable (the corresponding tile is of type Grass), false otherwise.
     */
    @Override
    public Boolean isPlaceable(Point p, Map map){
        return map.tiles[p.x][p.y].getClass().equals(Grass.class);
    }

    /**
     * Checks if the current forest at the given point can see
     * other forests on the map and influences their statistics.
     *
     * @param p The point of the current forest.
     * @param map The map object.
     */
    public void seesOtherForest(Point p, Map map){
        boolean sees = true;
        for(int i = 1; i <= 3; ++i){
            if((p.x+i) < map.tiles.length) {
                if (map.tiles[p.x + i][p.y].getClass().equals(Forest.class) && sees) {
                    Forest f = (Forest) map.tiles[p.x + i][p.y];
                    f.influenceStats(f.coordinate,map);
                    sees = false;
                }else if (!map.tiles[p.x + i][p.y].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        sees = true;
        for(int i = -1; i >= -3; --i){
            if((p.x+i) >= 0){
                if (map.tiles[p.x + i][p.y].getClass().equals(Forest.class) && sees) {
                    Forest f = (Forest) map.tiles[p.x + i][p.y];
                    f.influenceStats(f.coordinate,map);
                    sees = false;
                }else if (!map.tiles[p.x + i][p.y].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        sees = true;
        for(int i = 1; i <= 3; ++i){
            if((p.y+i) < map.tiles[p.x].length) {
                if (map.tiles[p.x][p.y + i].getClass().equals(Forest.class) && sees) {
                    Forest f = (Forest) map.tiles[p.x][p.y + i];
                    f.influenceStats(f.coordinate,map);
                    sees = false;
                }else if (!map.tiles[p.x][p.y + i].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        sees = true;
        for(int i = -1; i >= -3; --i){
            if((p.y+i) >= 0) {
                if (map.tiles[p.x][p.y + i].getClass().equals(Forest.class) && sees) {
                    Forest f = (Forest) map.tiles[p.x][p.y + i];
                    f.influenceStats(f.coordinate,map);
                    sees = false;
                }else if (!map.tiles[p.x][p.y + i].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
    }

    /**
     * Updates the influenced points of the current forest based
     * on its visibility to other zones on the map.
     *
     * @param p   The point of the current forest.
     * @param map The map object.
     */
    public void seenByForest(Point p, Map map){
        for(int i = 0; i < 4; ++i){
            this.influenced.set(i,p);
        }
        boolean sees = true;
        for(int i = 1; i <= 3; ++i){
            if((p.x+i) < map.tiles.length) {
                if (map.tiles[p.x + i][p.y].getClass().equals(Zone.class) && sees) {
                    Zone z = (Zone) map.tiles[p.x + i][p.y];
                    if (z.type.equals(ZoneType.RESIDENTIAL)) {
                        this.influenced.set(2, new Point(p.x + i, p.y));
                    }
                    sees = false;
                }else if (!map.tiles[p.x + i][p.y].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        if(this.influenced.get(2) == null){
            this.influenced.set(2, p);
        }
        sees = true;
        for(int i = -1; i >= -3; --i){
            if((p.x+i) >= 0){
                if (map.tiles[p.x + i][p.y].getClass().equals(Zone.class) && sees) {
                    Zone z = (Zone) map.tiles[p.x + i][p.y];
                    if (z.type.equals(ZoneType.RESIDENTIAL)) {
                        this.influenced.set(0, new Point(p.x + i, p.y));
                    }
                    sees = false;
                }else if (!map.tiles[p.x + i][p.y].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        if(this.influenced.get(0) == null){
            this.influenced.set(0, p);
        }
        sees = true;
        for(int i = 1; i <= 3; ++i){
            if((p.y+i) < map.tiles[p.x].length) {
                if (map.tiles[p.x][p.y + i].getClass().equals(Zone.class) && sees) {
                    Zone z = (Zone) map.tiles[p.x][p.y + i];
                    if (z.type.equals(ZoneType.RESIDENTIAL)) {
                        this.influenced.set(3, new Point(p.x, p.y + i));
                    }
                    sees = false;
                }else if (!map.tiles[p.x][p.y + i].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        if(this.influenced.get(3) == null){
            this.influenced.set(3, p);
        }
        sees = true;
        for(int i = -1; i >= -3; --i){
            if((p.y+i) >= 0) {
                if (map.tiles[p.x][p.y + i].getClass().equals(Zone.class) && sees) {
                    Zone z = (Zone) map.tiles[p.x][p.y + i];
                    if (z.type.equals(ZoneType.RESIDENTIAL)) {
                        this.influenced.set(1, new Point(p.x, p.y + i));
                    }
                    sees = false;
                }else if (!map.tiles[p.x][p.y + i].getClass().equals(Grass.class)) {
                    sees = false;
                }
            }
        }
        if(this.influenced.get(1) == null){
            this.influenced.set(1, p);
        }
    }

    /**
     * Overrides the influenceStats method.
     * Influences the stats of certain zones based on the state of the forest.
     *
     * @param p   The point used to search for the forest-influenced zones.
     * @param map The map containing the zones.
     */
    //friss erdo lehelyezese
    @Override
    public void influenceStats(Point p, Map map){
        if(this.isGrown) {
            for (Point pt : this.influenced) {
                if (map.tiles[pt.x][pt.y].getClass().equals(Zone.class)) {
                    Zone z = (Zone) map.tiles[pt.x][pt.y];
                    if (z.type.equals(ZoneType.RESIDENTIAL) && z.countPeople() != 1) {
                        z.influenceSat(-(this.effect));
                    }
                }
            }
            seenByForest(p, map);
            for (Point pt : this.influenced) {
                if (map.tiles[pt.x][pt.y].getClass().equals(Zone.class)) {
                    Zone z = (Zone) map.tiles[pt.x][pt.y];
                    if (z.type.equals(ZoneType.RESIDENTIAL)) {
                        z.influenceSat(this.effect);
                    }
                }
            }
        }
    }
    /**
     * Decreases the influence of the forest on certain zones.
     *
     * @param p   The point used to locate the influenced zones.
     * @param map The map containing the zones.
     */
    @Override
    public void deInfluenceStats(Point p, Map map){
        if(this.isGrown) {
            for (Point pt : this.influenced) {
                if (map.tiles[pt.x][pt.y].getClass().equals(Zone.class)) {
                    Zone z = (Zone) map.tiles[pt.x][pt.y];
                    z.influenceSat(-this.effect);
                }
            }
        }
    }

    /**
     * Corrects the image associated with the forest based on its growth state.
     *
     * @param map The map containing the forest.
     */
    private void correctImage(Map map) {
        String temp;
        if (!isGrown && currentTime > created + 100000) {
            isGrown = true;
            this.influenceStats(this.coordinate, map);
        }
        if (!isGrown) {
            temp = "src/main/java/org/gyorsfalu/forest_growing.png";
        }else{
            temp = "src/main/java/org/gyorsfalu/forest_grown.png";
        }
        this.image = new ImageIcon(temp).getImage();
    }

    /**
     * Draws the forest image on the graphics context at the specified point on the map.
     *
     * @param grphcs The graphics context on which to draw the image.
     * @param point  The point on the map where the image should be drawn.
     * @param map    The map containing the forest.
     */
    public void draw(Graphics grphcs, Point point, Map map) {
        correctImage(map);
        grphcs.drawImage(image, point.x * GamePanel.PIXEL_SIZE, point.y * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, null);
    }
}
