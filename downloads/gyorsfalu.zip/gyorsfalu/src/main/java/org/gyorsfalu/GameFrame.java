package org.gyorsfalu;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;


/**
 * The type Game frame.
 */
public class GameFrame extends JFrame {
    /**
     * The Gamepanel.
     */
    GamePanel gamepanel;

    /**
     * The Update timer.
     */
    Timer updateTimer;
    private long currentTime;
    private int timeElapsed;
    private int timeSpeedNum = 1;

    private JLabel moneyLabel;
    private JLabel popLabel;
    private JLabel popSatLabel;
    private JLabel timeLabel;

    /**
     * Constructs a GameFrame object, which represents the main frame of the game.
     * The GameFrame includes a GamePanel, option buttons, information labels, and a building scroll panel.
     * The constructor initializes the GUI components, sets up event listeners, and starts an update timer.
     */
    GameFrame() {
        gamepanel = new GamePanel();

        //top options panel and option buttons
        JPanel optionsPanel = new JPanel(new GridLayout(1, 6));
        optionsPanel.setPreferredSize(new Dimension(200, 50));
        JButton gameInfoBtn = new JButton();
        gameInfoBtn.setText("Game Info");
        gameInfoBtn.setPreferredSize(new Dimension(100, 10));

        JLabel gameInfoTxt = new JLabel("<html><div style='text-align: justify;'>"
                + "<h3>Welcome, Mayor of the Fast Village!</h3>"
                + "<p>Your task is to develop a thriving city where citizens are happy, and the budget is balanced. <br>The better the city's budget, and the lower the taxes, the more satisfied the citizens will be. Your task <br>is to achieve both at the same time.</p>"
                + "<p>You have to manage an initial capital, which you can use for construction and development. <br>Additionally, you collect taxes from the citizens. Be careful because the budget can also go negative, <br>which will result in dissatisfaction among the residents. In this case, you have the opportunity to get <br>money by demolishing buildings or increasing taxes.</p>"
                + "<h4>Construction:</h4>"
                + "<p>You can build roads, and it is recommended that they be connected to each other. You can only <br>build anything next to roads. You can build three different types of zones: residential, industrial, and <br>service zones. They have a one-time cost, and when new residents arrive, they build on them. It is essential<br> that a resident can only take a job if there is a road leading from their residence to a workplace. You can <br>also build service buildings such as police stations, fire stations, stadiums, and even forests. Please note <br>that these types of buildings not only have construction costs but also annual maintenance fees. However, <br>the advantage is that they all positively affect the satisfaction of residents, so it is important to have such <br>buildings close to residential areas. When the city is full, you can also raise the level of the zones, allowing <br>more residents to move in, and more employees to take jobs. This is how you can increase the city's capacity.</p>"
                + "<h4>Demolition:</h4>"
                + "<p>You can only cancel a zone layout if no buildings have been built on it yet. You can demolish service <br>buildings at any time. In this case, part of the construction cost will be refunded,and you will no longer have<br> to pay maintenance fees. Be especially careful when demolishing roads because if the connection between <br>a resident's workplace and residence is lost, they will not be able to go to work anymore.</p>"
                + "<h4>Disaster:</h4>"
                + "<p>Be careful because natural disasters may occur, so it is essential for the city to have fire stations.</p>"
                + "<h4>User Guide:</h4>"
                + "<p>To build something, select a building type, then click the left mouse button on the field where you want to <br>build. If you want to demolish something, select the field you want to demolish and click the right mouse button. <br>If you want to further develop a zone, select the zone to be developed and click the middle mouse button. If you <br>want to change the tax rate, press the 'change tax' button, adjust the slider, and press the 'ok' button. You can <br>report on the game's budget by clicking on the 'budget' button. If you want to start a new game,<br>press the 'new game' button.</p>"
                + "</div></html>");


        JLabel[] gameInfoArr = {gameInfoTxt};
        gameInfoBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, gameInfoArr, "Game Info", JOptionPane.PLAIN_MESSAGE);
            }
        });
        optionsPanel.add(gameInfoBtn);
        JButton timeSpeedBtn = new JButton();
        timeSpeedBtn.setText(">>");
        timeSpeedBtn.setPreferredSize(new Dimension(100, 10));
        timeSpeedBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timeSpeedNum == 0) {
                    timeSpeedBtn.setText(">>");
                    ++timeSpeedNum;
                    // gamepanel set time to normal
                } else if (timeSpeedNum == 1) {
                    timeSpeedBtn.setText(">>>");
                    ++timeSpeedNum;
                    // gamepanel set time to fast
                } else if (timeSpeedNum == 2) {
                    timeSpeedBtn.setText(">");
                    timeSpeedNum = 0;
                    // gamepanel set time to slow
                }
            }
        });
        optionsPanel.add(timeSpeedBtn);

        JButton changeTaxBtn = new JButton();
        changeTaxBtn.setText("Change Tax");

        changeTaxBtn.setPreferredSize(new Dimension(100, 10));
        changeTaxBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane optionPane = new JOptionPane();

                JSlider slider1 = new JSlider(0, 100, gamepanel.budget.residentalTax);
                JSlider slider2 = new JSlider(0, 100, gamepanel.budget.industrialTax);
                JSlider slider3 = new JSlider(0, 100, gamepanel.budget.servicesTax);

                slider1.setMajorTickSpacing(20);
                slider1.setPaintTicks(true);
                slider1.setPaintLabels(true);
                ChangeListener changeListener1 = new ChangeListener() {
                    public void stateChanged(ChangeEvent changeEvent) {
                        JSlider theSlider = (JSlider) changeEvent.getSource();
                        if (!theSlider.getValueIsAdjusting()) {
                            gamepanel.budget.residentalTax = (theSlider.getValue());
                            for (BuildingGraphics[] b : gamepanel.map.tiles) {
                                for (BuildingGraphics bg : b) {
                                    if (bg.getClass().equals(Zone.class)) {
                                        Zone z = (Zone) bg;
                                        if (z.type.equals(ZoneType.RESIDENTIAL)) {
                                            for (Person p : z.building.residents) {
                                                p.updateTax(theSlider.getValue());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                };
                slider1.addChangeListener(changeListener1);

                slider2.setMajorTickSpacing(20);
                slider2.setPaintTicks(true);
                slider2.setPaintLabels(true);
                ChangeListener changeListener2 = new ChangeListener() {
                    public void stateChanged(ChangeEvent changeEvent) {
                        JSlider theSlider = (JSlider) changeEvent.getSource();
                        if (!theSlider.getValueIsAdjusting()) {
                            gamepanel.budget.industrialTax = (theSlider.getValue());
                        }
                    }
                };
                slider2.addChangeListener(changeListener2);

                slider3.setMajorTickSpacing(20);
                slider3.setPaintTicks(true);
                slider3.setPaintLabels(true);
                ChangeListener changeListener3 = new ChangeListener() {
                    public void stateChanged(ChangeEvent changeEvent) {
                        JSlider theSlider = (JSlider) changeEvent.getSource();
                        if (!theSlider.getValueIsAdjusting()) {
                            gamepanel.budget.servicesTax = (theSlider.getValue());
                        }
                    }
                };
                slider3.addChangeListener(changeListener3);

                optionPane.setMessage(new Object[]{"Select tax percentage: ", "Residental:", slider1, "Industrial:", slider2, "Services", slider3});
                optionPane.setMessageType(JOptionPane.QUESTION_MESSAGE);
                optionPane.setOptionType(JOptionPane.OK_CANCEL_OPTION);
                JDialog dialog = optionPane.createDialog(null, "My Slider");
                dialog.setVisible(true);

            }
        });
        optionsPanel.add(changeTaxBtn);

        JButton budgetBtn = new JButton();
        budgetBtn.setText("Budget");

        budgetBtn.setPreferredSize(new Dimension(100, 10));
        budgetBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, gamepanel.budget.foreSight());
            }
        });
        optionsPanel.add(budgetBtn);

        JButton detailsButton = new JButton();
        detailsButton.setText("Check details");
        detailsButton.setPreferredSize(new Dimension(100, 10));
        detailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (detailsButton.getText().equals("Check details")) {
                    detailsButton.setText("Build mode");
                } else {
                    detailsButton.setText("Check details");
                }
                gamepanel.checkDetails = !gamepanel.checkDetails;
            }
        });
        optionsPanel.add(detailsButton);

        JButton firemanButton = new JButton();
        firemanButton.setText("Send firemen home");
        firemanButton.setPreferredSize(new Dimension(100, 10));
        firemanButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gamepanel.sendFiremanHome();
            }
        });
        optionsPanel.add(firemanButton);

        JButton disaster = new JButton();
        disaster.setText("Disaster");
        disaster.setPreferredSize(new Dimension(100, 10));
        disaster.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane optionPane = new JOptionPane();

                JButton button1 = new JButton();
                JButton button2 = new JButton();
                JButton button3 = new JButton();

                button1.setPreferredSize(new Dimension(100, 20));
                button2.setPreferredSize(new Dimension(100, 20));
                button3.setPreferredSize(new Dimension(100, 20));

                button1.setText("Fire");
                button2.setText("Meteor");
                button3.setText("Chemical");

                button1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        gamepanel.map.fireDisaster();
                    }
                });

                button2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        gamepanel.map.meteorDisaster();
                    }
                });

                button3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        gamepanel.map.chemicalDisaster();
                    }
                });

                optionPane.setMessage(new Object[]{"Fire a disaster event manually: ", button1, button2, button3});
                optionPane.setMessageType(JOptionPane.QUESTION_MESSAGE);
                optionPane.setOptionType(JOptionPane.OK_CANCEL_OPTION);
                JDialog dialog = optionPane.createDialog(null, "Disasters");
                dialog.setVisible(true);
            }
        });
        optionsPanel.add(disaster);

        //infoPanel and labels for gamepanel info
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(1, 4));
        Border blackBorder = BorderFactory.createLineBorder(Color.black);
        moneyLabel = new JLabel();
        moneyLabel.setText("Money: " + Budget.getCurrentMoney()); //gamepanel.getMoney()
        moneyLabel.setBorder(blackBorder);
        infoPanel.add(moneyLabel);
        popLabel = new JLabel();
        popLabel.setText("Population: " + gamepanel.people); //gamepanel.getPop()
        popLabel.setBorder(blackBorder);
        infoPanel.add(popLabel);
        popSatLabel = new JLabel();
        popSatLabel.setText("Population Satisfaction: "); //gamepanel.getPopSat()
        popSatLabel.setBorder(blackBorder);
        infoPanel.add(popSatLabel);
        timeLabel = new JLabel();
        timeLabel.setText("Current week: "); //gamepanel.getTime()
        timeLabel.setBorder(blackBorder);
        infoPanel.add(timeLabel);

        //building scrollpanel and building buttons
        JPanel scrollPanel = new JPanel();
        scrollPanel.setPreferredSize(new Dimension(1200, 120));
        scrollPanel.setAutoscrolls(true);
        JScrollPane scrollFrame = new JScrollPane(scrollPanel, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollFrame.setPreferredSize(new Dimension(1200, 120));
        scrollPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        //adds all building buttons to scrollpanel
        for (BuildingType t : BuildingType.values()) {
            if (t != BuildingType.GRASS) {
                JPanel buildingIcon = new JPanel();
                buildingIcon.setPreferredSize(new Dimension(70, 90));
                buildingIcon.setLayout(new BorderLayout());
                JButton b = new JButton();
                b.setIcon(new ImageIcon(new ImageIcon("src/main/java/org/gyorsfalu/" + t.toString() + ".png").getImage().getScaledInstance(70, 70, Image.SCALE_DEFAULT)));
                b.setPreferredSize(new Dimension(70, 70));
                b.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        if (t == BuildingType.EMPTY) {
                            gamepanel.setCurrentBuilding(null);
                        } else {
                            gamepanel.setCurrentBuilding(t);
                        }
                    }
                });
                JLabel btnName = new JLabel("", SwingConstants.CENTER);
                String buildName = t.toString();
                buildName = buildName.substring(0, 1).toUpperCase() + buildName.substring(1).toLowerCase();
                btnName.setText(buildName);
                buildingIcon.add(b, BorderLayout.NORTH);
                buildingIcon.add(btnName, BorderLayout.SOUTH);
                scrollPanel.add(buildingIcon);
            }
        }

        //setting the frame layout and adding the components to the frame
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.add(optionsPanel);
        this.add(gamepanel);
        this.add(infoPanel);
        this.add(scrollFrame);
        this.setTitle("GyorsFalu");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        updateTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                update();
            }
        });
        updateTimer.start();
        currentTime = System.currentTimeMillis();
    }

    /**
     * Updates the game time based on the time elapsed and notifies the GamePanel.
     */
    private void updateTime() {
        long timeDifference = (System.currentTimeMillis() - currentTime) * (timeSpeedNum + 1);
        currentTime = System.currentTimeMillis();
        if (convertTimeToWeeks(this.timeElapsed) != convertTimeToWeeks((int) timeDifference + timeElapsed)) {
            onNewWeek();
        }
        timeElapsed = (int) timeDifference + timeElapsed;
        gamepanel.onTimeElapse(timeElapsed);
    }

    /**
     * Updates the age of residents in the game by iterating through the zones on the game panel.
     * It updates the age of each resident and takes into account the residential tax rate from the budget.
     */
    private void updateResidents() {
        for (int x = 0; x < 30; x++) {
            for (int y = 0; y < 10; y++) {
                if (gamepanel.map.tiles[x][y].getClass() == Zone.class) {
                    for (int i = 0; i < ((Zone) gamepanel.map.tiles[x][y]).building.residents.size(); i++) {
                        ((Zone) gamepanel.map.tiles[x][y]).building.residents.get(i).updateAge(gamepanel.map, gamepanel.budget.residentalTax);
                    }
                }
            }
        }
    }

    /**
     * Handles actions to be taken when a new week starts in the game.
     * It updates the year income and, if the time elapsed is even, updates the year cost from the budget.
     * It also calculates the chance of a disaster occurring on the game map.
     * It updates the age of residents and adjusts the population based on the residential tax rate.
     * It assigns people to workplaces on the map.
     * It increments the current week counter.
     * If the budget is bankrupt or there are no people in the game (excluding early game), triggers game over.
     */
    private void onNewWeek() {
        for (int x = 0; x < 30; x++) {
            for (int y = 0; y < 10; y++) {
                if (PlayerBuild.class.isAssignableFrom(gamepanel.map.tiles[x][y].getClass())) {
                    if (((PlayerBuild) gamepanel.map.tiles[x][y]).isOnFire) {
                        if (((PlayerBuild) gamepanel.map.tiles[x][y]).weeksSinceFire > 3) {
                            gamepanel.map.demolish(((PlayerBuild) gamepanel.map.tiles[x][y]).coordinate);
                        } else {
                            ((PlayerBuild) gamepanel.map.tiles[x][y]).weeksSinceFire++;
                        }
                    } else {
                        ((PlayerBuild) gamepanel.map.tiles[x][y]).weeksSinceFire = 0;
                    }
                }
            }
        }
        gamepanel.budget.updateYearIncome();
        if (timeElapsed % 2 == 0) {
            gamepanel.budget.updateYearCost();
        }
        gamepanel.map.disasterChance();
        updateResidents();
        gamepanel.map.newPopulation(5, gamepanel.budget.residentalTax);
        gamepanel.map.peopleWorkplace();
        gamepanel.map.currentWeek++;
        if (gamepanel.budget.isBankrupt() || (!gamepanel.map.isEarlyGame()) && gamepanel.people == 0) {
            gameOver();
        }
    }

    /**
     * Triggers the game over state.
     * Displays a game over message dialog.
     * Closes the game window.
     */
    private void gameOver() {
        JOptionPane.showMessageDialog(null, "You have lost the game!", "Game over!", JOptionPane.PLAIN_MESSAGE);
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }

    /**
     * Converts the given time elapsed to weeks.
     *
     * @param timeElapsed The time elapsed in milliseconds.
     * @return The equivalent number of weeks.
     */
    private int convertTimeToWeeks(int timeElapsed) {
        return (int) Math.floor((double) timeElapsed / 10000);
    }

    /**
     * Updates the game state.
     * Updates time, money, population, population satisfaction, and current week labels.
     */
    private void update() {
        updateTime();
        moneyLabel.setText("Money: " + Budget.getCurrentMoney());
        popLabel.setText("Population: " + gamepanel.people);
        popSatLabel.setText("Population Satisfaction: " + Math.round(gamepanel.popSat));
        timeLabel.setText("Current week: " + convertTimeToWeeks(this.timeElapsed));
    }
}
