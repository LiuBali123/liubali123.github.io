package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;


/**
 * The type Game panel.
 */
public class GamePanel extends JPanel implements ActionListener {
    /**
     * The Screen width.
     */
    static final int SCREEN_WIDTH = 1200;

    /**
     * The Screen height.
     */
    static final int SCREEN_HEIGHT = 400;

    /**
     * The Pixel size.
     */
    static final int PIXEL_SIZE = 40;

    /**
     * The Delay.
     */
    static final int DELAY = 1;

    /**
     * The Check details.
     */
    boolean checkDetails = false;
    /**
     * The Running.
     */
    boolean running = false;
    /**
     * The People.
     */
    int people;
    /**
     * The Fire station.
     */
    Point fireStation;
    /**
     * The Fire man selected.
     */
    Point fireManSelected;
    /**
     * The Fire man selected for move.
     */
    Fireman fireManSelectedForMove;


    /**
     * The Pop sat.
     */
    double popSat;
    /**
     * The Timer.
     */
    Timer timer;
    /**
     * The Map.
     */
    Map map = new Map();
    /**
     * The Budget.
     */
    Budget budget = new Budget(10000);
    private BuildingType currentBuilding;

    /**
     * Instantiates a new Game panel.
     */
    GamePanel() {
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setVisible(true);
        this.addMouseListener(new PlaceBuildingListener());
        this.addMouseMotionListener(new HoverListener());
        this.popSat = 0;
        startGame();
    }

    /**
     * Starts the game.
     * Sets the game as running.
     * Initializes and starts the timer.
     */
    public void startGame() {
        running = true;
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    /**
     * Draws the game.
     * If the game is running, calls the "draw" method of the map object to draw the map with the current building.
     * @param grphcs the graphics object to draw on
     */
    public void draw(Graphics grphcs) {
        if (running) {
            map.draw(grphcs, currentBuilding);
        }
    }

    /**
     * Sets the current building.
     * @param building the building to set as the current building
     */
    public void setCurrentBuilding(BuildingType building) {
        this.currentBuilding = building;
    }

    /**
     * Builds a player build at the specified point.
     * @param p the point where the player build should be built
     * @return the player build object representing the built structure
     */
    public PlayerBuild build(Point p) {
        return switch (currentBuilding) {
            case ROAD -> new Road(p);
            case FIRE -> new FireStation(p);
            case POLICE -> new PoliceStation(p);
            case STADIUM -> new Stadium(p, 0);
            case RESIDENTIAL -> new Zone(p, ZoneType.RESIDENTIAL);
            case INDUSTRIAL -> new Zone(p, ZoneType.INDUSTRIAL);
            case SERVICES -> new Zone(p, ZoneType.SERVICES);
            case FOREST -> new Forest(p);
            default -> null;
        };
    }

    /**
     * Handles the actionPerformed event.
     * @param e the ActionEvent object
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        this.people = 0;
        ArrayList<Zone> zones = new ArrayList<>();
        ArrayList<PlayerBuild> build = new ArrayList<>();
        for (int i = 0; i < map.tiles.length; i++) {
            for (int j = 0; j < map.tiles[0].length; j++) {
                if (map.tiles[i][j].getClass() == Zone.class) {
                    if (((Zone) map.tiles[i][j]).type.equals(ZoneType.RESIDENTIAL)) {
                        this.people += ((Zone) map.tiles[i][j]).countPeople();
                    }
                    zones.add((Zone) map.tiles[i][j]);

                }
                if (map.tiles[i][j] instanceof PlayerBuild) {
                    build.add((PlayerBuild) map.tiles[i][j]);
                }
            }
        }
        budget.updateState(zones, build);
        repaint();
    }


    /**
     * Checks the details of a building at the given location.
     * @param p the location of the building
     */
    private void checkDetailsOfBuilding(Point p) {
        BuildingGraphics building = map.tiles[p.x][p.y];
        JFrame detailsFrame = new JFrame("details");
        detailsFrame.setSize(new Dimension(350, 350));
        detailsFrame.setLayout(new GridLayout(0, 1));
        int typeDataLen = building.getClass().toString().split(" ")[1].split("\\.").length;
        JLabel typeTitle = new JLabel("Building type:"+building.getClass().toString().split(" ")[1].split("\\.")[typeDataLen - 1]);
        detailsFrame.add(typeTitle);
        if (building.getClass() == Zone.class) {
            JLabel data1;
            String out = "";
            if (((Zone) building).level == -1) {
                out = "";
                out += "A meteor has hit the building, upgrade to rebuild the building";
                data1 = new JLabel(out);
            } else if (((Zone) building).level == 0) {
                out = "";
                out += "Chemical spill has occured, half of the residents are dead";
                data1 = new JLabel(out);
            } else {
                out = "";
                out += "Zone level:";
                out += ((Zone) building).level;
                data1 = new JLabel(out);
            }
            out = "";
            out += "Zone satisfaction:";
            out += ((Zone) building).satisfaction;
            JLabel data2 = new JLabel(out);
            out = "";
            out += "Zone capacity:";
            out += ((Zone) building).building.residents.size() + "/" + ((Zone) building).building.maxCapacity;
            JLabel data3 = new JLabel(out);
            out = "";
            detailsFrame.add(data1);
            detailsFrame.add(data2);
            detailsFrame.add(data3);
        }
        detailsFrame.setLocationRelativeTo(null);
        detailsFrame.setVisible(true);
    }
    /**
     * Calculates the population satisfaction.
     */
    private void calcPopSat() {
        double popSat = 0;
        int zoneNum = 0;
        for (BuildingGraphics[] tile : map.tiles) {
            for (BuildingGraphics t : tile) {
                if (t.getClass().equals(Zone.class)) {
                    ((Zone) t).calcSatisfaction();
                    if (((Zone) t).satisfaction != 0) {
                        ++zoneNum;
                        popSat += ((Zone) t).satisfaction;
                    }
                }
            }
        }
        if (zoneNum == 0) {
            popSat = popSat / 1;
        } else {
            popSat = popSat / zoneNum;
        }
        this.popSat = popSat;
    }


    /**
     * Updates the game state on time elapse.
     * @param timeElapsed The time elapsed in the game.
     */
    public void onTimeElapse(int timeElapsed) {
        calcPopSat();
        this.map.setTimeElapsed(timeElapsed);
        this.map.popSat = this.popSat;
    }

    /**
     * Mouse listener for placing buildings and interacting with the game map.
     */
    private class PlaceBuildingListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            Point p = new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE));

            if (fireStation != null) {
                ((FireStation) map.tiles[fireStation.x][fireStation.y]).moveFireMan(map, p, null);
            }
            fireStation = null;

            if (currentBuilding == BuildingType.ONFIRE) {
                if (fireManSelected != null) {
                    if (PlayerBuild.class.isAssignableFrom(map.tiles[p.x][p.y].getClass())) {
                        ((PlayerBuild) map.tiles[p.x][p.y]).putOutFire(map.fireManLocation);
                        fireManSelected = null;
                    }
                } else {
                    fireManSelected = map.isFireManThere(p) ? p : null;
                }
                return;
            }

            if (currentBuilding == null) {
                if (fireManSelectedForMove == null) {
                    for (Fireman f : map.fireManLocation) {
                        if (f.location.equals(p)) {
                            fireManSelectedForMove = f;
                        }
                    }
                } else {
                    for (int i = 0; i < map.tiles.length; i++) {
                        for (int j = 0; j < map.tiles[i].length; j++) {
                            if (map.tiles[i][j].getClass().equals(FireStation.class)) {
                                if (((FireStation) map.tiles[i][j]).fireManId == fireManSelectedForMove.id) {
                                    ((FireStation) map.tiles[i][j]).moveFireMan(map, p, fireManSelectedForMove.location);
                                    fireManSelectedForMove = null;
                                    return;
                                }
                            }
                        }
                    }
                }
            }

            if (checkDetails && e.getButton() == MouseEvent.BUTTON1) {
                checkDetailsOfBuilding(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                return;
            }
            if (currentBuilding == null && map.tiles[(int) Math.floor((float) e.getX() / PIXEL_SIZE)][(int) Math.floor((float) e.getY() / PIXEL_SIZE)].getClass().equals(FireStation.class)) {
                fireStation = new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE));
            }
            if (currentBuilding == null) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (map.tiles[(int) Math.floor((float) e.getX() / PIXEL_SIZE)][(int) Math.floor((float) e.getY() / PIXEL_SIZE)].getClass() == Zone.class) {
                        ((Zone) map.tiles[(int) Math.floor((float) e.getX() / PIXEL_SIZE)][(int) Math.floor((float) e.getY() / PIXEL_SIZE)]).levelup(budget);
                    }
                }
                return;
            }
            if (e.getButton() == MouseEvent.BUTTON1) {

                if (build(p).isPlaceable(p, map)) {
                    map.setBuilding(build(p), new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                    Budget.buildCost(build(p));
                }


            } else if (e.getButton() == MouseEvent.BUTTON3) {
                if (map.tiles[(int) Math.floor((float) e.getX() / PIXEL_SIZE)][(int) Math.floor((float) e.getY() / PIXEL_SIZE)].getClass().equals(Road.class)) {
                    map.demolish(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                    boolean right = map.canEveryoneReachWorkplace();
                    if (!right) {
                        map.setBuilding(new Road(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE))), new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                        int res = JOptionPane.showOptionDialog(null, "Deleting this road cuts connection(s) between people's homes and workplaces. Are you sure?",
                                "Removing road", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Yes", "No"}, JOptionPane.YES_OPTION);
                        if (res == JOptionPane.YES_OPTION) {
                            map.demolish(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                        }
                    }
                } else if (map.tiles[(int) Math.floor((float) e.getX() / PIXEL_SIZE)][(int) Math.floor((float) e.getY() / PIXEL_SIZE)].getClass().equals(Zone.class)) {
                    int res = JOptionPane.showOptionDialog(null, "Deleting this zone forces the people who live or work there to move. This is not always possible. Are you sure?",
                            "Removing zone", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Yes", "No"}, JOptionPane.YES_OPTION);
                    if (res == JOptionPane.YES_OPTION) {
                        map.demolish(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                    }
                } else {
                    map.demolish(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
                }
            }
            calcPopSat();
            repaint();
        }

        @Override
        public void mouseExited(MouseEvent e) {
            map.setHoveredPoint(null);
        }
    }
    /**
     * Mouse motion listener for handling hover and drag events on the game map.
    */
    private class HoverListener extends MouseMotionAdapter {
        @Override
        public void mouseMoved(MouseEvent e) {
            map.setHoveredPoint(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
            repaint();
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            Point p = new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE));

            if (currentBuilding == BuildingType.ONFIRE || fireStation != null) {
                return;
            }

            if (checkDetails) {
                return;
            }
            if (e.getX() >= SCREEN_WIDTH || e.getX() < 0 || e.getY() >= SCREEN_HEIGHT || e.getY() < 0) {
                return;
            }
            if (currentBuilding == null) {
                return;
            }

            if (build(p).isPlaceable(p, map)) {
                map.setBuilding(build(p), p);
                Budget.buildCost(build(p));
            }

            map.setHoveredPoint(new Point((int) Math.floor((float) e.getX() / PIXEL_SIZE), (int) Math.floor((float) e.getY() / PIXEL_SIZE)));
            calcPopSat();
            repaint();
        }
    }

    /**
     * Sends the firemen back to their respective fire stations.
     */
    public void sendFiremanHome() {
        for (int i = 0; i < map.tiles.length; i++) {
            for (int j = 0; j < map.tiles[i].length; j++) {
                if (map.tiles[i][j].getClass().equals(FireStation.class)) {
                    if (map.fireManLocation.size() != 0) {
                        for (Fireman f : map.fireManLocation) {
                            if (((FireStation) map.tiles[i][j]).fireManId == f.id) {
                                ((FireStation) map.tiles[i][j]).moveFireMan(map, ((FireStation) map.tiles[i][j]).getRoadNeighbor(map.tiles), f.location);
                            }
                        }
                    }
                }
            }
        }
    }
}
