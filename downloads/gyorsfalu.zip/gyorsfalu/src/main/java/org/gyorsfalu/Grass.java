package org.gyorsfalu;

import javax.swing.*;

/**
 * The type Grass.
 */
public class Grass extends BuildingGraphics {
    /**
     * Instantiates a new Grass.
     */
    public Grass() {
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/grass.png").getImage();
    }
}
