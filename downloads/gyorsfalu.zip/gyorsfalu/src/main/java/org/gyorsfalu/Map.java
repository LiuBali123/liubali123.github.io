package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * The type Map.
 */
public class Map {
    /**
     * The constant EARLY_GAME_WEEKS.
     */
    public static int EARLY_GAME_WEEKS = 20;
    /**
     * The Tiles.
     */
    public BuildingGraphics[][] tiles = new BuildingGraphics[GamePanel.SCREEN_WIDTH / GamePanel.PIXEL_SIZE][GamePanel.SCREEN_HEIGHT / GamePanel.PIXEL_SIZE];
    /**
     * The Fire man location.
     */
    ArrayList<Fireman> fireManLocation = new ArrayList<>();

    /**
     * The Residentials
     */
    ArrayList<Point> residentials = new ArrayList<>();
    /**
     * The Work places industrial
     */
    ArrayList<Point> workPlacesInd = new ArrayList<>();
    /**
     * The Work places servicies
     */
    ArrayList<Point> workPlacesSer = new ArrayList<>();
    /**
     * The Hovered point.
     */
    Point hoveredPoint;
    /**
     * The Graphics.
     */
    Graphics graphics;
    private int timeElapsed;

    /**
     * The Pop sat.
     */
    double popSat = 0;

    private Random random = new Random();

    public int currentWeek = 0;

    /**
     * Instantiates a new Map.
     */
    public Map() {
        this.newMap();
    }

    /**
     * Creates a new map with starting road and forests.
     */
    //creates new map with starting road and forests
    public void newMap() {
        Random r = new Random();
        int randomInt;
        int x = 0;
        for (BuildingGraphics[] tile : tiles) {
            int i = 0;
            for (BuildingGraphics t : tile) {
                randomInt = r.nextInt(100) + 1;
                if (randomInt <= 5) {//percentage for generating forest
                    tile[i] = new Forest(new Point(x, i));
                } else {
                    tile[i] = new Grass();
                }
                i++;
            }
            x++;
        }
        tiles[tiles.length / 2 - 1][tiles[0].length - 1] = new Road(new Point(tiles.length / 2 - 1, tiles[0].length - 1));
    }


    /**
     * Checks if there is a fireman at the specified location.
     * @param p the location to check
     * @return true if there is a fireman at the location, false otherwise
     */
    public boolean isFireManThere(Point p) {
        if (fireManLocation.size() != 0) {
            for (Fireman fireman : fireManLocation) {
                if (fireman.location.x == p.x && fireman.location.y == p.y) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * Draws the map and buildings on the graphics object.
     *
     * @param grphcs the graphics object to draw on
     * @param building the building type to highlight (optional)
     */
    public void draw(Graphics grphcs, BuildingType building) {
        this.graphics = grphcs;

        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                tiles[i][j].updateTime(timeElapsed, tiles);
                if (tiles[i][j].getClass().equals(Forest.class)) {
                    Forest f = (Forest) tiles[i][j];
                    f.draw(grphcs, new Point(i, j), this);
                } else {
                    tiles[i][j].draw(grphcs, new Point(i, j));
                }
                if (PlayerBuild.class.isAssignableFrom(tiles[i][j].getClass()) && ((PlayerBuild) tiles[i][j]).isOnFire) {
                    grphcs.drawImage(new ImageIcon("src/main/java/org/gyorsfalu/onfire.png").getImage(), i * GamePanel.PIXEL_SIZE, j * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, null);
                }
            }
        }
        if (hoveredPoint != null) {
            int multiplier = 1;
            if (building != null) {
                if (building.equals(BuildingType.STADIUM)) {
                    multiplier = 2;
                }
            }

            grphcs.setColor(new Color(0, 255, 0, 50));
            grphcs.fillRect(hoveredPoint.x * GamePanel.PIXEL_SIZE, hoveredPoint.y * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE * multiplier, GamePanel.PIXEL_SIZE * multiplier);
        }
        if (fireManLocation.size() != 0) {
            for (Fireman fireman : fireManLocation) {
                grphcs.drawImage(new ImageIcon("src/main/java/org/gyorsfalu/fireman.png").getImage(), fireman.location.x * GamePanel.PIXEL_SIZE, fireman.location.y * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, null);
            }
        }
    }

    /**
     * Assigns a new home for a person.
     *
     * @param person the person
     * @return true if a new home is assigned, false if all homes are full
     */
    //get a person a different home, and if all are full, return false
    public boolean newHome(Person person) {
        Collections.shuffle(residentials);
        boolean temp = false;
        for (Point p : residentials) {
            Zone currentResidential = (Zone) this.tiles[p.x][p.y];
            if (currentResidential.building.isThereSpace()) {
                currentResidential.addPerson(person);
                person.resetHome(currentResidential.building);
                temp = true;
                break;
            }
        }
        return temp;
    }

    /**
     * Generates a new population by placing a specified number of people in random houses.
     *
     * @param x the number of people to generate
     * @param resTax the residential tax rate
     */
    //get X amount of people in the city in random houses
    public void newPopulation(int x, double resTax) {
        if (popSat > 50 || isEarlyGame()) {
            Collections.shuffle(residentials);
            int i = 0;
            int newPeople = x;
            Zone currentZone;
            while (i < residentials.size() && newPeople > 0) {
                currentZone = (Zone) tiles[residentials.get(i).x][residentials.get(i).y];
                while (currentZone.building.isThereSpace() && newPeople > 0) {
                    Building closest = closestWorkPlace(currentZone.coordinate);
                    if (closest != null || isEarlyGame()) {
                        Person person = new Person(currentZone.building, closest, resTax);
                        if (currentZone.countPeople() == 0) {
                            currentZone.addPerson(person);
                            currentZone.influenceStats(currentZone.coordinate, this);
                        } else {
                            currentZone.addPerson(person);
                        }
                        currentZone.calcSatisfaction();
                        if (closest != null) {
                            closest.addPerson(person);
                            closest.calcSatisfaction();
                        }
                    }
                    newPeople--;
                }
                i++;
            }
        }
    }

    /**
     * Checks if the people can reach their workplaces,
     * and if not, assigns them a new one or removes them.
     */
    //checks if the people can reach the workplace, and if not, give them a new one, and if cant, remove them
    public void peopleWorkplace() {
        for (int i = 0; i < residentials.size(); i++) {
            ArrayList<Person> removeThese = new ArrayList<>();
            for (int j = 0; j < (((Zone) tiles[residentials.get(i).x][residentials.get(i).y]).building.residents).size(); j++) {
                Person person = (((Zone) tiles[residentials.get(i).x][residentials.get(i).y]).building.residents).get(j);
                if (person.workplace == null || !connection(person.workplace.zone.coordinate, person.home.zone.coordinate)) {
                    if (person.workplace != null) {
                        person.workplace.removePerson(person);
                    }
                    Building closest = closestWorkPlace(person.home.zone.coordinate);
                    if (closest == null && person.isOutOfJob) {
                        if (!isEarlyGame()) {
                            removeThese.add(person);
                        }
                    } else {
                        person.isOutOfJob = true;
                    }
                    person.resetWorkplace(closest);
                    if (closest != null && person.age < 65) {
                        person.workplace = closest;
                        closest.addPerson(person);
                    }
                }
            }
            for (Person person : removeThese) {
                (((Zone) tiles[residentials.get(i).x][residentials.get(i).y]).building).removePerson(person);
            }
        }

    }

    /**
     * Can everyone reach workplace boolean.
     *
     * @return the boolean
     */
    //checks if every person can reach their workplace, if they have one
    public boolean canEveryoneReachWorkplace() {
        for (int i = 0; i < residentials.size(); i++) {
            for (int j = 0; j < (((Zone) tiles[residentials.get(i).x][residentials.get(i).y]).building.residents).size(); j++) {
                Person person = (((Zone) tiles[residentials.get(i).x][residentials.get(i).y]).building.residents).get(j);
                if (person.workplace != null && !connection(person.workplace.zone.coordinate, person.home.zone.coordinate)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Checks if every person can reach their workplace, if they have one.
     * @return true if everyone can reach their workplace, false otherwise
     */
    //returns the closest building to p with space, if there are none, returns null
    private Building closestWorkPlace(Point p) {
        ArrayList<Point> workPlaces = lessWorkers();
        if (workPlaces == null) {
            return null;
        }
        int i = 0;
        if (workPlaces.size() > 0) {
            workPlaces.sort((p1, p2) -> (ifNullReturnMax(path(getRoadNeighbor(p1), p)) > ifNullReturnMax(path(getRoadNeighbor(p2), p))) ? 1 : -1);
            while (i < workPlaces.size() && !((Zone) tiles[workPlaces.get(i).x][workPlaces.get(i).y]).building.isThereSpace()) {
                i++;
            }
        }
        if (i < workPlaces.size()) {
            if (path(getRoadNeighbor(p), workPlaces.get(i)) == null) {
                return null;
            }
            return ((Zone) tiles[workPlaces.get(i).x][workPlaces.get(i).y]).building;
        }
        return null;
    }

    /**
     * Returns the size of the ArrayList if it is not null, otherwise returns Integer.MAX_VALUE.
     *
     * @param x the ArrayList to check
     * @return the size of the ArrayList if it is not null, otherwise Integer.MAX_VALUE
     */
    private int ifNullReturnMax(ArrayList<Point> x) {
        if (x == null) {
            return Integer.MAX_VALUE;
        }
        return x.size();
    }

    /**
     * Finds a path from point p1 to point p2 using the A* algorithm.
     *
     * @param p1 the starting point
     * @param p2 the destination point
     * @return an ArrayList of Points representing the path from p1 to p2, or null if no path exists
     */
    private ArrayList<Point> path(Point p1, Point p2) {
        if (!tiles[p1.x][p1.y].getClass().equals(Road.class)) {
            return null;
        }
        int rows = tiles.length;
        int cols = tiles[0].length;
        boolean[][] visited = new boolean[rows][cols];
        int[][] distances = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            Arrays.fill(distances[i], Integer.MAX_VALUE);
        }
        distances[p1.x][p1.y] = 0;
        PriorityQueue<Point> queue = new PriorityQueue<>(Comparator.comparingInt(a -> distances[a.x][a.y]));
        queue.offer(p1);
        while (!queue.isEmpty()) {
            Point curr = queue.poll();
            if (tiles[curr.x][curr.y].getClass().equals(Road.class)) {
                if (visited[curr.x][curr.y]) {
                    continue;
                }
                visited[curr.x][curr.y] = true;
                int dist = distances[curr.x][curr.y];
                for (Point neighbor : getNeighbors(curr, rows, cols)) {
                    if (tiles[neighbor.x][neighbor.y].getClass().equals(Road.class)) {
                        int newDist = dist + getDistance(curr, neighbor);
                        if (newDist < distances[neighbor.x][neighbor.y]) {
                            distances[neighbor.x][neighbor.y] = newDist;
                            queue.offer(neighbor);
                        }
                    }
                }
            }
        }
        return backtrack(distances, p1, getRoadNeighbor(p2));
    }

    /**
     * Checks if two buildings are connected by a road.
     *
     * @param p1 the coordinate of the first building
     * @param p2 the coordinate of the second building
     * @return true if there is a road connection between the buildings, false otherwise
     */
    //check if 2 buildings are connected by a road
    public boolean connection(Point p1, Point p2) {
        ArrayList<Point> path = path(getRoadNeighbor(p1), p2);
        return path != null;
    }

    /**
     * Backtracks the shortest path from the target to the start using the given distances matrix.
     * @param distances the matrix of distances representing the shortest distances from each point to the start point
     * @param start the starting point
     * @param target the target point
     * @return the shortest path from the target to the start as a list of points, including both start and target points, or null if there is no path from the target to the start
     */
    private ArrayList<Point> backtrack(int[][] distances, Point start, Point target) {
        ArrayList<Point> path = new ArrayList<>();
        Point curr = target;
        if (distances[target.x][target.y] == Integer.MAX_VALUE) {
            return null;
        }
        while (!curr.equals(start)) {
            path.add(curr);
            int dist = distances[curr.x][curr.y];
            for (Point neighbor : getNeighbors(curr, distances.length, distances[0].length)) {
                if (distances[neighbor.x][neighbor.y] == dist - getDistance(curr, neighbor)) {
                    curr = neighbor;
                    break;
                }
            }
        }
        path.add(start);
        return path;
    }

    /**
     * Gets the neighboring points of a given point within the specified grid dimensions.
     * @param p the point for which to find neighbors
     * @param rows the number of rows in the grid
     * @param cols the number of columns in the grid
     * @return a list of neighboring points of the given point
     */
    private ArrayList<Point> getNeighbors(Point p, int rows, int cols) {
        ArrayList<Point> neighbors = new ArrayList<>();
        if (p.x > 0) {
            neighbors.add(new Point(p.x - 1, p.y));
        }
        if (p.x < rows - 1) {
            neighbors.add(new Point(p.x + 1, p.y));
        }
        if (p.y > 0) {
            neighbors.add(new Point(p.x, p.y - 1));
        }
        if (p.y < cols - 1) {
            neighbors.add(new Point(p.x, p.y + 1));
        }
        return neighbors;
    }

    /**
     * Retrieves a neighboring road coordinate for the given coordinate.
     * @param coordinate the coordinate for which to find a road neighbor
     * @return a neighboring coordinate that represents a road, or the same coordinate if no road neighbor is found
     */
    private Point getRoadNeighbor(Point coordinate) {
        if (coordinate.x > 0) {
            if (tiles[coordinate.x - 1][coordinate.y].getClass().equals(Road.class)) {
                return new Point(coordinate.x - 1, coordinate.y);
            }
        }
        if (coordinate.x < tiles.length - 1) {
            if (tiles[coordinate.x + 1][coordinate.y].getClass().equals(Road.class)) {
                return new Point(coordinate.x + 1, coordinate.y);
            }
        }
        if (coordinate.y > 0) {
            if (tiles[coordinate.x][coordinate.y - 1].getClass().equals(Road.class)) {
                return new Point(coordinate.x, coordinate.y - 1);
            }
        }
        return new Point(coordinate.x, coordinate.y + 1);
    }

    /**
     * Calculates the Manhattan distance between two points.
     * @param a the first point
     * @param b the second point
     * @return the Manhattan distance between the two points
     */
    private int getDistance(Point a, Point b) {
        int dx = a.x - b.x;
        int dy = a.y - b.y;
        return Math.abs(dx) + Math.abs(dy);
    }

    /**
     * Determines the list of work places with fewer workers.
     *
     * @return the list of work places with fewer workers, or null if all work places are fully occupied
     */
    //return if service or industrial zones have less workers, if there are no space in any of them, returns null
    private ArrayList<Point> lessWorkers() {
        int serWorkers = 0;
        boolean isThereSpaceInd = false;
        boolean isThereSpaceSer = false;
        int indWorkers = 0;
        for (Point p : workPlacesInd) {
            indWorkers += ((Zone) tiles[p.x][p.y]).building.residents.size();
            if (((Zone) tiles[p.x][p.y]).building.isThereSpace()) {
                isThereSpaceInd = true;
            }
        }
        for (Point p : workPlacesSer) {
            serWorkers += ((Zone) tiles[p.x][p.y]).building.residents.size();
            if (((Zone) tiles[p.x][p.y]).building.isThereSpace()) {
                isThereSpaceSer = true;
            }
        }
        if (!isThereSpaceInd && !isThereSpaceSer) {
            return null;
        }
        if ((serWorkers < indWorkers || !isThereSpaceInd) && isThereSpaceSer) {
            return workPlacesSer;
        }
        return workPlacesInd;
    }

    /**
     * Checks if the current game state is in the early game phase.
     * @return true if the current week is within the early game weeks, false otherwise
     */
    //gives back true if the game is in the first X weeks
    public boolean isEarlyGame() {
        return currentWeek <= EARLY_GAME_WEEKS;
    }

    /**
     * Sets hovered point.
     *
     * @param hoveredPoint the hovered point
     */
    public void setHoveredPoint(Point hoveredPoint) {
        this.hoveredPoint = hoveredPoint;
    }

    /**
     * Sets a building at the specified point on the game map.
     *
     * @param building the building to be set
     * @param point the coordinates of the point where the building will be set
     */
    public void setBuilding(PlayerBuild building, Point point) {
        if (building.getClass().equals(Stadium.class)) {
            tiles[point.x][point.y] = new Stadium(point, 0);
            tiles[point.x + 1][point.y] = new Stadium(point, 1);
            PlayerBuild std1 = (PlayerBuild) tiles[point.x + 1][point.y];
            std1.influenceStats(std1.coordinate, this);
            tiles[point.x][point.y + 1] = new Stadium(point, 2);
            PlayerBuild std2 = (PlayerBuild) tiles[point.x][point.y + 1];
            std2.influenceStats(std2.coordinate, this);
            tiles[point.x + 1][point.y + 1] = new Stadium(point, 3);
            PlayerBuild std3 = (PlayerBuild) tiles[point.x + 1][point.y + 1];
            std3.influenceStats(std3.coordinate, this);
        } else if (building.getClass().equals(Zone.class)) {
            if (((Zone) building).type.equals(ZoneType.RESIDENTIAL)) {
                residentials.add(point);
            } else if (((Zone) building).type.equals(ZoneType.INDUSTRIAL)) {
                workPlacesInd.add(point);
            } else {
                workPlacesSer.add(point);
            }
            tiles[point.x][point.y] = building;
            tiles[point.x][point.y].created = timeElapsed;
            ((Zone) building).coordinate = point;
        } else if (building.getClass().equals(Forest.class)) {
            Forest f = (Forest) building;
            tiles[point.x][point.y] = building;
            f.seesOtherForest(f.coordinate, this);
            tiles[point.x][point.y].created = timeElapsed;
        } else {
            tiles[point.x][point.y] = building;
            tiles[point.x][point.y].created = timeElapsed;
        }
        building.influenceStats(point, this);
    }

    /**
     * Demolishes a building at the specified point on the game map.
     * @param point the coordinates of the point where the building will be demolished
     */
    public void demolish(Point point) {
        if (residentials.contains(point)) {
            residentials.remove(point);
        } else if (workPlacesSer.contains(point)) {
            workPlacesSer.remove(point);
        } else {
            workPlacesInd.remove(point);
        }
        //cant destroy starting road
        if (!(point.x == (tiles.length / 2 - 1) && point.y == (tiles[0].length - 1)) && !tiles[point.x][point.y].getClass().equals(Grass.class)) {
            Budget.demolishMoney((PlayerBuild) tiles[point.x][point.y]);
            if (tiles[point.x][point.y].getClass().equals(PoliceStation.class)) {
                PlayerBuild building = (PlayerBuild) tiles[point.x][point.y];
                building.deInfluenceStats(point, this);
                tiles[point.x][point.y].demolish(point, this);
            } else if (tiles[point.x][point.y].getClass().equals(Forest.class)) {
                Forest building = (Forest) tiles[point.x][point.y];
                tiles[point.x][point.y].demolish(point, this);
                building.seesOtherForest(building.coordinate, this);
                building.deInfluenceStats(point, this);
            } else {
                PlayerBuild building = (PlayerBuild) tiles[point.x][point.y];
                tiles[point.x][point.y].demolish(point, this);
                building.deInfluenceStats(point, this);
            }
        }
    }

    /**
     * Determines the chance of a disaster occurring in the game.
     * If a disaster occurs, it can be either a meteor disaster or a chemical disaster.
     */
    public void disasterChance() {
        int rand = random.nextInt(5000);
        if (rand < 10) {
            if (rand % 2 == 0) {
                meteorDisaster();
            }
            if (rand % 2 == 1) {
                chemicalDisaster();
            }
        }
    }

    /**
     * Triggers a meteor disaster in the game.
     * Selects a random zone and sets its level to -1, indicating destruction.
     * Removes all residents from the affected zone and sets its maximum capacity to 0.
     */
    public void meteorDisaster() {
        ArrayList<Zone> zones = new ArrayList<Zone>();
        for (int x = 0; x < 30; x++) {
            for (int y = 0; y < 10; y++) {
                if (tiles[x][y].getClass() == Zone.class) {
                    zones.add(((Zone) tiles[x][y]));
                }
            }
        }
        if (zones.size() > 0) {
            int selected = random.nextInt(zones.size());
            zones.get(selected).level = -1;
            ArrayList<Person> persons = new ArrayList<Person>(zones.get(selected).building.residents);
            for (int j = 0; j < persons.size(); j++) {
                persons.get(j).unlink();
            }
            zones.get(selected).building.maxCapacity = 0;
        }

    }

    /**
     * Triggers a chemical disaster in the game.
     * Selects a random zone and sets its level to 0, indicating contamination.
     * Removes half of the residents from the affected zone.
     */
    public void chemicalDisaster() {
        ArrayList<Zone> zones = new ArrayList<Zone>();
        for (int x = 0; x < 30; x++) {
            for (int y = 0; y < 10; y++) {
                if (tiles[x][y].getClass() == Zone.class) {
                    zones.add(((Zone) tiles[x][y]));
                }
            }
        }
        if (zones.size() > 0) {
            int selected = random.nextInt(zones.size());
            zones.get(selected).level = 0;
            ArrayList<Person> persons = new ArrayList<Person>(zones.get(selected).building.residents);
            for (int j = 0; j < persons.size(); j++) {
                if (j % 2 == 0) {
                    persons.get(j).unlink();
                }
            }
        }
    }

    /**
     * Triggers a fire disaster in the game.
     * Selects a random zone and sets it on fire.
     */
    public void fireDisaster() {
        ArrayList<Zone> zones = new ArrayList<Zone>();
        for (int x = 0; x < 30; x++) {
            for (int y = 0; y < 10; y++) {
                if (tiles[x][y].getClass() == Zone.class) {
                    zones.add(((Zone) tiles[x][y]));
                }
            }
        }
        if (zones.size() > 0) {
            int selected = random.nextInt(zones.size());
            zones.get(selected).setOnFire();
        }
    }

    /**
     * Spawns a new person in the city, afther someone died
     * @param resTax the residential tax rate
     */
    public void spawn(double resTax) {
        Building home = null;
        Building workplace = null;
        Point p = null;

        for (int x = 0; x < tiles.length; x++) {
            for (int y = 0; y < tiles[0].length; y++) {
                if (tiles[x][y].getClass() == Zone.class) {
                    if (((Zone) tiles[x][y]).type == ZoneType.RESIDENTIAL) {
                        if (((Zone) tiles[x][y]).building.maxCapacity > ((Zone) tiles[x][y]).building.residents.size()) {
                            home = ((Zone) tiles[x][y]).building;
                            p = new Point(x, y);
                        }
                    }
                }
            }
        }
        for (int x = 0; x < tiles.length; x++) {
            for (int y = 0; y < tiles[0].length; y++) {
                if (tiles[x][y].getClass() == Zone.class) {
                    if (((Zone) tiles[x][y]).type == ZoneType.INDUSTRIAL && home != null && connection(new Point(x, y), p)) {
                        if (((Zone) tiles[x][y]).building.maxCapacity > ((Zone) tiles[x][y]).building.residents.size()) {
                            workplace = ((Zone) tiles[x][y]).building;
                        }
                    }
                    if (((Zone) tiles[x][y]).type == ZoneType.SERVICES && home != null && connection(new Point(x, y), p)) {
                        if (((Zone) tiles[x][y]).building.maxCapacity > ((Zone) tiles[x][y]).building.residents.size()) {
                            workplace = ((Zone) tiles[x][y]).building;
                        }
                    }
                }
            }
        }
        if (home != null) {
            Person person = new Person(home, workplace, 18, resTax);
            home.residents.add(person);
            if (workplace != null) {
                workplace.residents.add(person);
            }
        }
    }

    /**
     * Sets time elapsed.
     *
     * @param timeElapsed the time elapsed
     */
    public void setTimeElapsed(int timeElapsed) {
        this.timeElapsed = timeElapsed;
    }
}
