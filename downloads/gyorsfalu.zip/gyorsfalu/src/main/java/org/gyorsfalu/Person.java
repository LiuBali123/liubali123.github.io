package org.gyorsfalu;

import java.util.Random;

/**
 * The type Person.
 */
public class Person {
    /**
     * The Age.
     */
    int age;
    /**
     * The Satisfaction.
     */
    double satisfaction;
    /**
     * The Money.
     */
    int money;
    /**
     * The Income.
     */
    int income;
    /**
     * The Avg tax.
     */
    double avgTax;
    /**
     * The Death chance.
     */
    int deathChance;
    /**
     * The Safe home.
     */
    Boolean safeHome;
    /**
     * The Safe work.
     */
    Boolean safeWork;
    /**
     * The Current tax.
     */
    double currentTax;
    /**
     * The Bad tax.
     */

    Random rand = new Random();
    Boolean badTax;
    /**
     * The Tax sum.
     */
    //nyugdij miatt eddigi befizetett adok
    int taxSum = 0;
    /**
     * The Is out of job.
     */
    boolean isOutOfJob = false;
    /**
     * The Home.
     */
    Building home;
    /**
     * The Workplace.
     */
    Building workplace;

    /**
     * Instantiates a new Person.
     *
     * @param home the home building
     * @param workplace the workplace building
     * @param tax the residential tax rate
     */
    Person(Building home, Building workplace, double tax) {
        if(home.satisfaction == 0){
            this.satisfaction = 50;
        }else{
            this.satisfaction = 50 - (50 - home.satisfaction)/2;
        }
        this.age = rand.nextInt(18,61); // random szam 18 es 60 kozott
        // az elegedettseg erteke kezdesnek az otthonanak az atlag satisfactionje
        this.money = 1000; // ez meg nem fix
        this.deathChance = 0;
        this.avgTax = 0;
        this.home = home;
        this.workplace = workplace;
        this.income = 600; // ez majd a munkahely alapjan kap erteket
        // (workplace.getWage -> pl random szam x es y ertek kozott)
        this.safeHome = false;
        this.safeWork = false;
        this.badTax = false;
        this.currentTax = 20;
        updateTax(tax);
    }

    /**
     * Instantiates a new Person, afther someone died.
     *
     * @param home the home building
     * @param workplace the workplace building
     * @param age the age of the person
     * @param tax the residential tax rate
     */
     Person(Building home, Building workplace, int age, double tax) {
        if(home.satisfaction == 0){
            this.satisfaction = 50;
        }else{
            this.satisfaction = 50 - (50 - home.satisfaction)/2;
        }
        this.age = age; // random szam 18 es 60 kozott
        // az elegedettseg erteke kezdesnek az otthonanak az atlag satisfactionje
        this.money = 1000; // ez meg nem fix
        this.deathChance = 0;
        this.avgTax = 0;
        this.home = home;
        this.workplace = workplace;
        this.income = 600; // ez majd a munkahely alapjan kap erteket
        // (workplace.getWage -> pl random szam x es y ertek kozott)
        this.safeHome = false;
        this.safeWork = false;
        this.badTax = false;
        this.currentTax = 20;
        updateTax(tax);
    }

    /**
     * Updates the age of the person.
     *
     * @param m the map object
     * @param resTax the residential tax rate
     */
    public void updateAge(Map m, double resTax) {
        // ezt a gamepanel hivja meg, minden nap megnezi melyik residential zona lakoknak van
        // aznap szuletesnapja, es azokon hivodik meg
        this.age+=1;
        // 65 eves kortol nyugdijba megy az ember
        if (this.age == 65) {
            retire();
        }
        // 65 eves kor felett egyelore 1%-kal (meg nem fix) no az elhalalozas eselye minden szuletesnapon
        // itt ki is sorsolodik deathChance alapjan, hogy meghal-e azon a szuletesnapon
        if (this.age > 65) {
            this.deathChance += 20;
            if(rand.nextInt(100)>100-deathChance){
                unlink();
                m.spawn(resTax);
            }
        }
    }

    /**
     * Retires the person.
     *
     * The person leaves their workplace
     */
    private void retire() {
        // nyugdijba megy az ember:
        // "elhagyja" a munkahelyet es atallitodik a keresete a nyugdijara, ami az elozo
        // 20 ev eves ado atlaganak fele lesz
        if(this.workplace!=null) {
            this.workplace.removePerson(this);
        }
        this.workplace = null;
        this.income = 500; // nyugdij erteke
    }

    /**
     * Resets the person's home.
     *
     * @param home The new home building for the person.
     */
    public void resetHome(Building home) {
        // abban az esetben, ha lerombolnank az epuletet(/zonat) ahol lakik, uj otthont kap
        // rombolaskor minden lakosra meghivodik, es random szabad hellyel rendelkezo
        // residential buildinget kap (amit megkap parameterkent)
        this.home = home;
        // ez esetben lehet hogy munkahelyet is ujra kell sorsolni, mivel
        // lehetseges, hogy olyan otthont kap, ahonnan nem elerheto (/nem idealis?) az
        // eddigi munkahelye
    }

    /**
     * Resets the person's workplace.
     *
     * @param workplace The new workplace building for the person.
     */
    public void resetWorkplace(Building workplace) {
        // abban az esetben, ha lerombolnank az epuletet(/zonat) ahol dolgozik, uj munkahelyet kap
        // rombolaskor minden munkasra meghivodik es ujrasorsol nekik workplace-t a home
        // kozelsege alapjan (amit megkap parameterkent)
        this.workplace = workplace;
        // majd at kell allitani a fizetest az uj munkahelynek megfeleloen
        // this.income = workplace.income;
    }

    /**
     * Influences the person's satisfaction.
     *
     * @param effect The amount of influence on the person's satisfaction.
     */
    public void influenceSat(int effect){
        this.satisfaction += effect;
    }

    /**
     * Calculates the person's satisfaction based on the safety of their home and workplace.
     * Updates the satisfaction value accordingly.
     */
    public void calcSat(){
        if(home.isSafe && !safeHome){
            safeHome = true;
            this.satisfaction += 5;
        }
        if(!home.isSafe && safeHome){
            safeHome = false;
            this.satisfaction -= 5;
        }
        if(workplace != null) {
            if (workplace.isSafe && !safeWork) {
                safeWork = true;
                this.satisfaction += 5;
            }
            if (!workplace.isSafe && safeWork) {
                safeWork = false;
                this.satisfaction -= 5;
            }
        }
    }

    /**
     * Calculates and returns the current satisfaction level of the person.
     *
     * @return The satisfaction level.
     */
    public double getSatisfaction() {
        calcSat();
        return this.satisfaction;
    }


    /**
     * Unlinks the person from their home and workplace.
     */
    public void unlink() {
        home.removePerson(this);
        home=null;
        if(workplace != null){
            workplace.removePerson(this);
            workplace=null;
        }
    }

    /**
     * Updates the tax for the person.
     *
     * @param tax the new tax value
     */
    public void updateTax(double tax){
        this.currentTax = tax;
        if(this.currentTax >= 25 && !this.badTax){
            this.satisfaction -= 15;
            this.badTax = true;
        }else if(this.currentTax < 25 && this.badTax){
            this.satisfaction += 15;
            this.badTax = false;
        }
    }
}
