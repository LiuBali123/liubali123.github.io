package org.gyorsfalu;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * The type Player build.
 */
public abstract class PlayerBuild extends BuildingGraphics {
    /**
     * The constant OUT_OF_CHANCE.
     */
    public static int OUT_OF_CHANCE = 10000000;
    /**
     * The constant FIRE_CHANCE.
     */
    public static int FIRE_CHANCE = 5;
    /**
     * The constant NEIGHBOR_FIRE_CHANCE.
     */
    public static int NEIGHBOR_FIRE_CHANCE = 200;
    /**
     * The Coordinate.
     */
    Point coordinate;
    /**
     * The Is flammable.
     */
    Boolean isFlammable = true;
    /**
     * The Is on fire.
     */
    Boolean isOnFire = false;
    /**
     * The Is built.
     */
    Boolean isBuilt = false;
    /**
     * The Map.
     */
    Map map;
    /**
     * The Price.
     */
    int price;
    /**
     * The Upkeep.
     */
    //evi fenttartasi koltseg miatt fontos
    int upkeep;
    /**
     * The Radius.
     */
    int radius;
    /**
     * The Effect.
     */
    int effect;
    int weeksSinceFire = 0;
    private final Random rand = new Random();

    /**
     * Instantiates a new Player build.
     *
     * @param p the coordinate of the player build
     */
    PlayerBuild(Point p) {
        this.coordinate = p;
        this.radius = 3;
        this.effect = 0;
    }

    /**
     * Update the time for the player build.
     */
    @Override
    public void onUpdateTime() {
        if (isFlammable && !isOnFire) {
            if (rand.nextInt(OUT_OF_CHANCE) < FIRE_CHANCE) {
               setOnFire();
            }
        }

        if (isOnFire) {
            if (coordinate.x - 1 >= 0) {
                if (rand.nextInt(OUT_OF_CHANCE) < NEIGHBOR_FIRE_CHANCE && PlayerBuild.class.isAssignableFrom(tiles[coordinate.x - 1][coordinate.y].getClass())
                        && ((PlayerBuild) tiles[coordinate.x - 1][coordinate.y]).isFlammable && !((PlayerBuild) tiles[coordinate.x - 1][coordinate.y]).isOnFire) {
                    ((PlayerBuild) tiles[coordinate.x - 1][coordinate.y]).setOnFire();
                }
            }
            if (coordinate.y + 1 < tiles[0].length) {
                if (rand.nextInt(OUT_OF_CHANCE) < NEIGHBOR_FIRE_CHANCE && PlayerBuild.class.isAssignableFrom(tiles[coordinate.x][coordinate.y + 1].getClass())
                        && ((PlayerBuild) tiles[coordinate.x][coordinate.y + 1]).isFlammable && !((PlayerBuild) tiles[coordinate.x][coordinate.y + 1]).isOnFire) {
                    ((PlayerBuild) tiles[coordinate.x][coordinate.y + 1]).setOnFire();
                }
            }
            if (coordinate.x + 1 < tiles.length) {
                if (rand.nextInt(OUT_OF_CHANCE) < NEIGHBOR_FIRE_CHANCE && PlayerBuild.class.isAssignableFrom(tiles[coordinate.x + 1][coordinate.y].getClass())
                        && ((PlayerBuild) tiles[coordinate.x + 1][coordinate.y]).isFlammable && !((PlayerBuild) tiles[coordinate.x + 1][coordinate.y]).isOnFire) {
                    ((PlayerBuild) tiles[coordinate.x + 1][coordinate.y]).setOnFire();
                }
            }
            if (coordinate.y - 1 >= 0) {
                if (rand.nextInt(OUT_OF_CHANCE) < NEIGHBOR_FIRE_CHANCE && PlayerBuild.class.isAssignableFrom(tiles[coordinate.x][coordinate.y - 1].getClass())
                        && ((PlayerBuild) tiles[coordinate.x][coordinate.y - 1]).isFlammable && !((PlayerBuild) tiles[coordinate.x][coordinate.y - 1]).isOnFire) {
                    ((PlayerBuild) tiles[coordinate.x][coordinate.y - 1]).setOnFire();
                }
            }
        }
    }

    /**
     * Sets on fire.
     */
    public void setOnFire() {
        isOnFire = true;
    }

    /**
     * Put out the fire with the help of firemen.
     *
     * @param firemen the list of firemen
     */
    public void putOutFire(ArrayList<Fireman> firemen) {
        boolean firemanNextToIt = false;
        for (Fireman f : firemen) {
            if (coordinate.x - 1 >= 0 && f.location.x == coordinate.x - 1 && f.location.y == coordinate.y) {
                firemanNextToIt = true;
            }
            if (coordinate.y + 1 < tiles[0].length && f.location.x == coordinate.x && f.location.y == coordinate.y + 1) {
                firemanNextToIt = true;
            }
            if (coordinate.x + 1 < tiles.length && f.location.x == coordinate.x + 1 && f.location.y == coordinate.y) {
                firemanNextToIt = true;
            }
            if (coordinate.y - 1 >= 0 && f.location.x == coordinate.x && f.location.y == coordinate.y - 1) {
                firemanNextToIt = true;
            }
        }
        if (firemanNextToIt) {
            isOnFire = false;
        }
    }

    /**
     * Checks if the building is placeable on the given tile.
     *
     * @param p the coordinates of the tile
     * @param map the map object
     * @return true if the building is placeable, false otherwise
     */
    //check if the building is placeable, meaning if the tile(s) we are placing it on are only grass, and if the building would be connected to a road
    public Boolean isPlaceable(Point p, Map map) {
        //checks if every tile that is needed for the building is grass
        if (!map.tiles[p.x][p.y].getClass().equals(Grass.class)) {
            return false;
        }
        //checks if there is at least 1 road connected to the building we want to build
        Boolean temp = false;
        //right of building
        if (p.x - 1 >= 0) {
            if (map.tiles[p.x - 1][p.y].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //top
        if (p.y + 1 < map.tiles[0].length) {
            if (map.tiles[p.x][p.y + 1].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //left
        if (p.x + 1 < map.tiles.length) {
            if (map.tiles[p.x + 1][p.y].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //bot
        if (p.y - 1 >= 0) {
            if (map.tiles[p.x][p.y - 1].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        return temp;
    }

    //destroys the building by replacing it with grass
    @Override
    public void demolish(Point coord, Map map) {
        map.tiles[coord.x][coord.y] = new Grass();
    }


    /**
     * Influences the happiness level of neighboring zones within the
     * specified radius based on the effect of this building.
     *
     * @param p the coordinates of the building on the map
     * @param map the map object representing the game map
     */
    //changes the happiness level in the radius based on this building's effect
    public void influenceStats(Point p, Map map) {
        for (int i = -radius; i <= radius; ++i) {
            if((p.x+i) < map.tiles.length && (p.x+i) >= 0) {
                for (int j = -radius; j <= radius; ++j) {
                    if((p.y+j) < map.tiles[p.x + i].length && (p.y+j) >= 0 &&  !(i == 0 && j == 0)) {
                        if (map.tiles[p.x + i][p.y + j].getClass().equals(Zone.class)) {
                            Zone z = (Zone) map.tiles[p.x + i][p.y + j];
                            if(map.tiles[p.x][p.y].getClass().equals(PoliceStation.class)){
                                z.building.handleSafety(true);
                            }
                            if(z.type.equals(ZoneType.RESIDENTIAL)) {
                                z.influenceSat(effect);
                            }
                        }
                        if(!map.tiles[p.x+i][p.y+j].getClass().equals(Grass.class) && !map.tiles[p.x+i][p.y+j].getClass().equals(Road.class)){
                            if(map.tiles[p.x][p.y].getClass().equals(Zone.class)){
                                Zone z = (Zone) map.tiles[p.x][p.y];
                                if(!map.tiles[p.x + i][p.y + j].getClass().equals(Forest.class)) {
                                    PlayerBuild building = (PlayerBuild) map.tiles[p.x + i][p.y + j];

                                    int distanceX = Math.abs(Math.abs(p.x) - Math.abs(p.x + i));
                                    int distanceY = Math.abs(Math.abs(p.y) - Math.abs(p.y + j));

                                    if (distanceX <= building.radius && distanceY <= building.radius) {
                                        if (building.getClass().equals(PoliceStation.class)) {
                                            z.building.handleSafety(true);
                                        }
                                        if (z.type.equals(ZoneType.RESIDENTIAL)) {
                                            z.influenceSat(building.effect);
                                        }

                                    }
                                }else{
                                    Forest f = (Forest) map.tiles[p.x + i][p.y + j];
                                    f.influenceStats(new Point(p.x + i,p.y + j),map);
                                }


                            }else{
                                if(map.tiles[p.x + i][p.y + j].getClass().equals(Forest.class)){
                                    Forest f = (Forest) map.tiles[p.x + i][p.y + j];
                                    f.influenceStats(new Point(p.x + i,p.y + j),map);
                                }
                            }


                        }
                    }
                }
            }
        }
    }

    /**
     * De-influences the happiness level of neighboring zones within the
     * specified radius by reversing the effect of this building.
     *
     * @param p the coordinates of the building on the map
     * @param map the map object representing the game map
     */
    public void deInfluenceStats(Point p, Map map){
        for(int i = -radius; i <= radius; ++i){
            if((p.x+i) < map.tiles.length && (p.x+i) >= 0) {
                for (int j = -radius; j <= radius; ++j) {
                    if((p.y+j) < map.tiles[p.x + i].length && (p.y+j) >= 0 &&  !(i == 0 && j == 0)){
                        if (map.tiles[p.x + i][p.y + j].getClass().equals(Zone.class)) {
                            Zone z = (Zone) map.tiles[p.x + i][p.y + j];
                            if(map.tiles[p.x][p.y].getClass().equals(PoliceStation.class)){
                                z.building.handleSafety(false);
                            }
                            if(z.type.equals(ZoneType.RESIDENTIAL)) {
                                z.influenceSat(-effect);
                            }

                        }
                        if(map.tiles[p.x + i][p.y + j].getClass().equals(Forest.class)){
                            Forest f = (Forest) map.tiles[p.x + i][p.y + j];
                            f.influenceStats(new Point(p.x + i,p.y + j),map);
                        }
                    }
                }
            }
        }
    }

}
