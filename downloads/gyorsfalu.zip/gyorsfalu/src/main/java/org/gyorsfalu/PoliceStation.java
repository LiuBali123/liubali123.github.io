package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;

/**
 * The type Police station.
 */
public class PoliceStation extends PlayerBuild {
    /**
     * Instantiates a new Police station building.
     *
     * @param p the coordinates of the building on the map
     */
    PoliceStation(Point p) {
        super(p);
        this.upkeep=200;
        this.price=150;
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/police.png").getImage();//PLACEHOLDER PIC
        this.radius = 5;
    }
}
