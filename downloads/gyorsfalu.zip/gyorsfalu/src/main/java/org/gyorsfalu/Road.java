package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;

/**
 * The type Road.
 */
public class Road extends PlayerBuild {
    /**
     * Instantiates a new Road building.
     *
     * @param p the coordinates of the building on the map
     */
    public Road(Point p) {
        super(p);
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/road.png").getImage();
        this.price = 10;
        this.upkeep = 10;
        this.isFlammable = false;
    }
}
