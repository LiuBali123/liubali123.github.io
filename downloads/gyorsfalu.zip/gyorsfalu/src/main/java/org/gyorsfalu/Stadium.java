package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;

/**
 * The type Stadium.
 */
public class Stadium extends PlayerBuild {

    /**
     * The Corner.
     */
    int corner;

    /**
     * Instantiates a new Stadium building.
     *
     * @param p the coordinates of the building on the map
     * @param n the corner number of the stadium
     */
    Stadium(Point p, int n) {
        super(p);
        this.image = new ImageIcon("src/main/java/org/gyorsfalu/stadium.png").getImage();//PLACEHOLDER PIC
        this.radius = 8;
        this.effect = 5;
        this.price = 700;
        this.upkeep = 500;
        if (n == 0) {
            this.image = new ImageIcon("src/main/java/org/gyorsfalu/stadium/stadium1.png").getImage();
        } else {
            this.image = new ImageIcon("src/main/java/org/gyorsfalu/stadium/stadium" + (n + 1) + ".png").getImage();
        }
        corner = n;
    }

    /**
     * Checks if a building is placeable at the specified position on the map.
     *
     * @param p   the coordinates of the top-left tile of the building
     * @param map the map object representing the game map
     * @return true if the building is placeable, false otherwise
     */
    @Override
    public Boolean isPlaceable(Point p, Map map) {
        //for 2x2 building(s), the top left part of the building is where the mouse is
        if (p.x + 2 > map.tiles.length || p.y + 2 > map.tiles[0].length) {
            return false;
        }
        //checks if every tile that is needed for the building is grass
        if (!map.tiles[p.x][p.y].getClass().equals(Grass.class) ||
                !map.tiles[p.x][p.y + 1].getClass().equals(Grass.class) ||
                !map.tiles[p.x + 1][p.y].getClass().equals(Grass.class) ||
                !map.tiles[p.x + 1][p.y + 1].getClass().equals(Grass.class)) {
            return false;
        }
        //checks if there is at least 1 road connected to the building we want to build
        Boolean temp = false;
        //TOP
        if (p.x - 1 >= 0) {
            if (map.tiles[p.x - 1][p.y + 0].getClass().equals(Road.class) ||
                    map.tiles[p.x - 1][p.y + 1].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //RIGHT
        if (p.y + 2 < map.tiles[0].length) {
            if (map.tiles[p.x + 0][p.y + 2].getClass().equals(Road.class) ||
                    map.tiles[p.x + 1][p.y + 2].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //BOTTOM
        if (p.x + 2 < map.tiles.length) {
            if (map.tiles[p.x + 2][p.y + 0].getClass().equals(Road.class) ||
                    map.tiles[p.x + 2][p.y + 1].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        //LEFT
        if (p.y - 1 >= 0) {
            if (map.tiles[p.x + 0][p.y - 1].getClass().equals(Road.class) ||
                    map.tiles[p.x + 1][p.y - 1].getClass().equals(Road.class)) {
                temp = true;
            }
        }
        return temp;
    }

    /**
     * Demolishes the building at the specified coordinates on the map.
     * Refunds the cost of the demolished building and removes its influence on neighboring tiles.
     *
     * @param coord the coordinates of the building to demolish
     * @param map the map containing the building
     */
    @Override
    public void demolish(Point coord, Map map) {
        //refund
        switch (corner) {
            case 0:
                map.tiles[coord.x][coord.y] = new Grass();
                PlayerBuild std1 = (PlayerBuild)map.tiles[coord.x + 1][coord.y];
                std1.deInfluenceStats(new Point(coord.x + 1,coord.y),map);
                map.tiles[coord.x + 1][coord.y] = new Grass();
                PlayerBuild std2 = (PlayerBuild)map.tiles[coord.x][coord.y + 1];
                std2.deInfluenceStats(new Point(coord.x,coord.y + 1),map);
                map.tiles[coord.x][coord.y + 1] = new Grass();
                PlayerBuild std3 = (PlayerBuild)map.tiles[coord.x + 1][coord.y + 1];
                std3.deInfluenceStats(new Point(coord.x + 1,coord.y + 1),map);
                map.tiles[coord.x + 1][coord.y + 1] = new Grass();
                break;
            case 1:
                map.demolish(new Point(coord.x - 1, coord.y));
                break;
            case 2:
                map.demolish(new Point(coord.x, coord.y - 1));
                break;
            case 3:
                map.demolish(new Point(coord.x - 1, coord.y - 1));
                break;
        }
    }
}
