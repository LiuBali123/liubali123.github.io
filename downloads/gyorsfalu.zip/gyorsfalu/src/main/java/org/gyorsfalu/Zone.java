package org.gyorsfalu;

import javax.swing.*;
import java.awt.*;

/**
 * The type Zone.
 */
public class Zone extends PlayerBuild {
    /**
     * The Type.
     */
    ZoneType type;
    /**
     * The Is empty.
     */
    Boolean isEmpty;
    /**
     * The Satisfaction.
     */
    double satisfaction;
    /**
     * The Building.
     */
    Building building;
    /**
     * The Level.
     */
    int level=1;
    /**
     * The Point.
     */

    /**
     * Instantiates a new Zone.
     *
     * @param p the coordinates of the zone
     * @param type the type of the zone
     */
    Zone(Point p, ZoneType type) {
        super(p);
        this.isEmpty = true;
        this.satisfaction = 0;
        this.type = type;
        this.building = new Building(p, this);
        this.price = 100;
        if(type.equals(ZoneType.RESIDENTIAL)){
            this.radius = 8;
        }else if(type.equals(ZoneType.INDUSTRIAL)){
            this.radius = 4;
            this.effect = -10;
        }else{
            this.radius = 5;
        }
    }

    /**
     * Adds a person to the zone.
     *
     * @param p the person to be added
     */
    public void addPerson(Person p) {
        this.building.addPerson(p);
    }


    /**
     * Counts the number of people in the zone.
     *
     * @return the number of people in the zone
     */
    public int countPeople() {
        return building.countResidents();
    }

    /**
     * Calculates the satisfaction level of the zone based on the happiness of its residents.
     * The satisfaction level influences the growth and development of the zone.
     */
    //calculates happiness
    public void calcSatisfaction() {
        this.satisfaction = building.calcSatisfaction();
    }

    /**
     * Influences the satisfaction level of the zone by applying the specified effect.
     * The effect can be positive or negative, representing an increase or decrease in satisfaction.
     *
     * @param effect the effect to apply to the satisfaction level
     */
    public void influenceSat(int effect){
        if(this.type.equals(ZoneType.RESIDENTIAL)) {
            if ((this.satisfaction + effect) <= 100) {
                building.influenceSat(effect);
            }else{
                int remainingSat = 100 - (int)Math.round(this.satisfaction);
                building.influenceSat(remainingSat);
            }
            calcSatisfaction();
        }
    }

    /**
     * Corrects the image of the zone based on its current state.
     * This method is responsible for updating the image of the zone
     * based on its level, progress, and other factors.
     * It ensures that the correct image is displayed for the zone.
     */
    private void correctImage() {
        String temp;
        if (isEmpty && currentTime > created + 5000) {
            isEmpty = false;
            building.level++;
            building.maxCapacity += 10;
            building.progress = 0;
        }
        if (building.level == 0 || building.progress != 0) {
            temp = "src/main/java/org/gyorsfalu/progress.png";
        }else {
            temp = "src/main/java/org/gyorsfalu/" + type.name().toLowerCase() + "level" + this.level + ".png";

            if(this.level==2)
                temp = "src/main/java/org/gyorsfalu/" + type.name().toLowerCase() + "level" + this.level + ".png";

            if (this.level==3)
                temp = "src/main/java/org/gyorsfalu/" + type.name().toLowerCase() + "level" + this.level + ".png";

            if(this.level==-1)
                temp = "src/main/java/org/gyorsfalu/" + "meteor" + ".png";

            if(this.level==-0)
                temp = "src/main/java/org/gyorsfalu/" + "chemical.png";
        }
        this.image = new ImageIcon(temp).getImage();
    }

    /**
     * Draws the zone on the game panel.
     *
     * @param grphcs The graphics object used for drawing.
     * @param point The top-left corner position of the zone on the game panel.
     */
    @Override
    public void draw(Graphics grphcs, Point point) {
        correctImage();
        grphcs.drawImage(image, point.x * GamePanel.PIXEL_SIZE, point.y * GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, GamePanel.PIXEL_SIZE, null);
    }

    /**
     * Increases the level of the zone.
     *
     * @param budget The budget object to deduct the required funds from.
     */
    public void levelup(Budget budget){
        if(this.level<3) {

            switch (this.level) {
                case -1:
                    //Katasztrófa miatt kell, ha meteor érte akkor level=0 onnan upgrade -el lehet feljavitano level 1 -re
                    this.building.maxCapacity = 20;
                    budget.setCurrentMoney(Budget.getCurrentMoney() - 200);
                    this.level+=2;
                    break;

                //katasztrófa miatt kell, ha chemical katasztrófa volt ott az épület
                //level=0 onnan upgrade -el lehet a vegyi anyagoktol megszabadulni
                case 0:
                    this.building.maxCapacity = 20;
                    budget.setCurrentMoney(Budget.getCurrentMoney() - 50);
                    this.level++;
                    break;
                case 1:
                    this.building.maxCapacity += 15;
                    budget.setCurrentMoney(Budget.getCurrentMoney() - 200);
                    this.level++;
                    break;

                case 2:
                    this.building.maxCapacity += 25;
                    budget.setCurrentMoney(Budget.getCurrentMoney() - 500);
                    this.level++;
                    break;

            }
        }
    }


    /**
     * Demolishes the zone at the specified coordinates and removes its influence on the map.
     * Refunds residents or removes their workplace associations if applicable.
     *
     * @param coord The coordinates of the zone to demolish.
     * @param map The map object from which to remove the zone.
     */
    //destroys the zone, and if residental, finds new home for the people
    @Override
    public void demolish(Point coord, Map map) {
        //refund TODO
        if(type.equals(ZoneType.RESIDENTIAL)){
            for(int i = 0; i < building.residents.size(); i++){
                boolean temp = map.newHome(building.residents.get(i));
                if(!temp){
                    if(building.residents.get(i).workplace != null) building.residents.get(i).workplace.removePerson(building.residents.get(i));
                }
            }
        }else{
            for(Person person : building.residents){
                person.workplace = null;
            }
        }
        map.tiles[coord.x][coord.y] = new Grass();
    }
}
