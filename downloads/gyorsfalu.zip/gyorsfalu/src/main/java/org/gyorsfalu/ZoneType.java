package org.gyorsfalu;

/**
 * The enum Zone type.
 */
public enum ZoneType {
    /**
     * Residential zone type.
     */
    RESIDENTIAL,
    /**
     * Industrial zone type.
     */
    INDUSTRIAL,
    /**
     * Services zone type.
     */
    SERVICES
}
