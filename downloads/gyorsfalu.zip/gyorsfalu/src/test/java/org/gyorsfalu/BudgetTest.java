package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;

public class BudgetTest extends TestCase {

    Budget budget;

    @Before
    public void setUp() {
        budget = new Budget(10000);
    }

    @Test
    public void testBudgetCalculations() {
        ArrayList<Zone> zones = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            zones.add(new Zone(new Point(0, 0), ZoneType.RESIDENTIAL));
        }

        ArrayList<PlayerBuild> zonesWorkPlace = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            zonesWorkPlace.add(new Zone(new Point(0, 0), i % 2 == 0 ? ZoneType.INDUSTRIAL : ZoneType.SERVICES));
            zones.add((Zone) zonesWorkPlace.get(i));
        }

        zonesWorkPlace.add(new PoliceStation(new Point(0, 0)));

        for (int i = 0; i < 10; i++) {
            Person p = new Person(zones.get(i).building, ((Zone) zonesWorkPlace.get(i)).building, 10);
            zones.get(i).addPerson(p);
            ((Zone) zonesWorkPlace.get(i)).addPerson(p);
            ((Zone) zonesWorkPlace.get(i)).type = i % 2 == 0 ? ZoneType.INDUSTRIAL : ZoneType.SERVICES;
        }

        budget.updateState(zones, zonesWorkPlace);

        assert (budget.foreSight().equals("Building costs: 0\nTax incomes: 800\nUpkeep: -200\nPension: 0"));

        budget.updateYearIncome();
        assert (Budget.getCurrentMoney() == 10800);

        budget.updateYearCost();
        assert (Budget.getCurrentMoney() == 10600);

    }
}
