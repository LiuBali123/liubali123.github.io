package org.gyorsfalu;

import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class BuildingTest {

    Zone zone;


    @Before
    public void setUp() {
        zone = new Zone(new Point(0,0), ZoneType.RESIDENTIAL);
    }

    @Test
    public void testCalculations() {
        zone.building.maxCapacity = 10;
        zone.building.addPerson(new Person(zone.building, null, 10));
        assert(zone.building.countResidents() == 1);
        assert(zone.building.isThereSpace());
        zone.building.calcSatisfaction();
        assert(zone.building.satisfaction == 50);
        zone.building.handleSafety(false);
        assert(zone.building.safeNum == 0);
        zone.building.influenceSat(10);
        assert(zone.building.satisfaction == 60);
    }

}
