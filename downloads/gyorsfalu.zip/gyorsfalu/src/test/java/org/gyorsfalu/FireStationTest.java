package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class FireStationTest extends TestCase {

    FireStation fireStation;
    Map map;

    @Before
    public void setUp() {
        fireStation = new FireStation(new Point(1, 0));
        map = new Map();
    }

    @Test
    public void testDijkstra() {
        map.tiles[0][0] = new Road(new Point(0, 0));
        map.tiles[0][1] = new Road(new Point(0, 1));
        map.tiles[1][0] = fireStation;
        fireStation.moveFireMan(map, new Point(0, 1), fireStation.getRoadNeighbor(map.tiles));
        assert (fireStation.isFiremanMoving);
    }

    @Test
    public void testDijkstraNoRoad() {
        map.tiles[1][0] = fireStation;
        fireStation.moveFireMan(map, new Point(5, 5), fireStation.getRoadNeighbor(map.tiles));
        assert (!fireStation.isFiremanMoving);
    }
}
