package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class ForestTest extends TestCase {
    Map map;

    @Before
    public void setUp() {
        map = new Map();
    }

    @Test
    public void testSatUp() {
        Point forestPoint = new Point(0,0);
        Point zonePoint = new Point(0,1);
        Forest forest = new Forest(forestPoint);
        Zone zone = new Zone(zonePoint, ZoneType.RESIDENTIAL);
        map.setBuilding(zone, zonePoint);
        zone.building.maxCapacity = 10;
        zone.addPerson(new Person(zone.building, null, 10));
        zone.calcSatisfaction();
        assert(zone.satisfaction == 50);
        map.setBuilding(forest, forestPoint);
        forest.isGrown = true;
        forest.influenceStats(forestPoint, map);
        assert(zone.satisfaction == 60);
    }


    @Test
    public void testSatDown() {
        Point forestPoint = new Point(0,1);
        Point zonePoint = new Point(0,0);
        Forest forest = new Forest(forestPoint);
        Zone zone = new Zone(zonePoint, ZoneType.RESIDENTIAL);
        map.setBuilding(zone, zonePoint);
        zone.building.maxCapacity = 10;
        zone.addPerson(new Person(zone.building, null, 10));
        zone.calcSatisfaction();
        assert(zone.satisfaction == 50);
        map.setBuilding(forest, forestPoint);
        forest.isGrown = true;
        forest.influenceStats(forestPoint, map);
        assert(zone.satisfaction == 60);
    }

    @Test
    public void testSatRight() {
        Point forestPoint = new Point(0,0);
        Point zonePoint = new Point(1,0);
        Forest forest = new Forest(forestPoint);
        Zone zone = new Zone(zonePoint, ZoneType.RESIDENTIAL);
        map.setBuilding(zone, zonePoint);
        zone.building.maxCapacity = 10;
        zone.addPerson(new Person(zone.building, null, 10));
        zone.calcSatisfaction();
        assert(zone.satisfaction == 50);
        map.setBuilding(forest, forestPoint);
        forest.isGrown = true;
        forest.influenceStats(forestPoint, map);
        assert(zone.satisfaction == 60);
    }

    @Test
    public void testSatLeft() {
        Point forestPoint = new Point(1,0);
        Point zonePoint = new Point(0,0);
        Forest forest = new Forest(forestPoint);
        Zone zone = new Zone(zonePoint, ZoneType.RESIDENTIAL);
        map.setBuilding(zone, zonePoint);
        zone.building.maxCapacity = 10;
        zone.addPerson(new Person(zone.building, null, 10));
        zone.calcSatisfaction();
        assert(zone.satisfaction == 50);
        map.setBuilding(forest, forestPoint);
        forest.isGrown = true;
        forest.influenceStats(forestPoint, map);
        assert(zone.satisfaction == 60);
    }

    @Test
    public void testDeInfluenceStats() {
        Point forestPoint = new Point(0,0);
        Point zonePoint = new Point(1,0);
        Forest forest = new Forest(forestPoint);
        Zone zone = new Zone(zonePoint, ZoneType.RESIDENTIAL);
        map.setBuilding(zone, zonePoint);
        zone.building.maxCapacity = 10;
        zone.addPerson(new Person(zone.building, null, 10));
        zone.calcSatisfaction();
        assert(zone.satisfaction == 50);
        map.setBuilding(forest, forestPoint);
        forest.isGrown = true;
        forest.influenceStats(forestPoint, map);
        assert(zone.satisfaction == 60);

        forest.deInfluenceStats(forestPoint, map);
        assert(zone.satisfaction == 50);
    }
}
