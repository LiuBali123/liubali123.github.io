package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class MapTest extends TestCase {

    Map map;
    @Before
    public void setUp() {
        map = new Map();
        map.newMap();
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                map.tiles[i][j] = new Grass();
            }
        }
    }

    @Test
    public void testHover() {
        map.setHoveredPoint(new Point(1,1));
        assertEquals(map.hoveredPoint, new Point(1,1));
    }
    @Test
    public void testFiremanThere() {
        Point p = new Point(1, 1);
        Fireman fireman = new Fireman(0, p);
        map.fireManLocation.add(fireman);
        assertTrue(map.isFireManThere(p));
    }
    @Test
    public void testNewHome() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        map.residentials.add(p);
        Person person = new Person(new Zone(new Point(0,0), ZoneType.RESIDENTIAL).building, null, 20);
        assertTrue(map.newHome(person));
        assertTrue(((Zone)map.tiles[map.residentials.get(0).x][map.residentials.get(0).y]).building.residents.contains(person));
    }
    @Test
    public void testNewPop() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        map.residentials.add(home.coordinate);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        map.newPopulation(1, 0);
        int totalPop = 0;
        for(Point p2 : map.residentials){
            totalPop += ((Zone)map.tiles[p2.x][p2.y]).building.residents.size();
        }
        assertEquals(1, totalPop);
    }
    @Test
    public void testNewPop2() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        map.residentials.add(home.coordinate);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        p = new Point(1, 3);
        Zone workplace = new Zone(p, ZoneType.SERVICES);
        map.workPlacesSer.add(p);
        workplace.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = workplace;
        p = new Point(1, 2);
        map.tiles[p.x][p.y] = new Road(p);
        map.newPopulation(1, 0);


        assertEquals(1, workplace.building.residents.size());
    }
    @Test
    public void testPeopleWorkPlace() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        map.residentials.add(home.coordinate);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        p = new Point(1, 3);
        Zone workplace = new Zone(p, ZoneType.SERVICES);
        map.workPlacesSer.add(p);
        workplace.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = workplace;
        p = new Point(1, 2);
        map.tiles[p.x][p.y] = new Road(p);
        map.newPopulation(1,0);
        p = new Point(1, 3);
        workplace.demolish(p, map);
        map.workPlacesSer.clear();
        map.peopleWorkplace();

        assertNull(home.building.residents.get(0).workplace);
    }
    @Test
    public void testCanEveryoneReachWorkPlace() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        map.residentials.add(home.coordinate);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        p = new Point(1, 3);
        Zone workplace = new Zone(p, ZoneType.SERVICES);
        map.workPlacesSer.add(p);
        workplace.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = workplace;
        p = new Point(1, 2);
        map.tiles[p.x][p.y] = new Road(p);
        map.newPopulation(1,0);
        map.tiles[p.x][p.y].demolish(p, map);

        assertFalse(map.canEveryoneReachWorkplace());
    }
    @Test
    public void testConnection() {
        Point p = new Point(1, 1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        map.residentials.add(home.coordinate);
        home.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = home;
        p = new Point(1, 3);
        Zone workplace = new Zone(p, ZoneType.SERVICES);
        map.workPlacesSer.add(p);
        workplace.building.maxCapacity = 1;
        map.tiles[p.x][p.y] = workplace;
        p = new Point(1, 2);
        map.tiles[p.x][p.y] = new Road(p);
        map.newPopulation(1,0);
        p = new Point(1, 3);

        assertTrue(map.connection(p, new Point(1, 1)));
    }
    @Test
    public void testSetBuilding() {
        Point p = new Point(1, 1);
        map.setBuilding(new Zone(p, ZoneType.RESIDENTIAL), p);

        assertEquals(ZoneType.RESIDENTIAL, ((Zone)map.tiles[p.x][p.y]).type);
    }
    @Test
    public void testSetBuilding2() {
        Point p = new Point(1, 1);
        map.setBuilding(new Stadium(p, 0), p);

        assertEquals(0, ((Stadium)map.tiles[p.x][p.y]).corner);
        assertEquals(1, ((Stadium)map.tiles[p.x+1][p.y]).corner);
        assertEquals(2, ((Stadium)map.tiles[p.x][p.y+1]).corner);
        assertEquals(3, ((Stadium)map.tiles[p.x+1][p.y+1]).corner);
    }
    @Test
    public void testDemolish() {
        Point p = new Point(1, 1);
        map.setBuilding(new Zone(p, ZoneType.RESIDENTIAL), p);
        map.demolish(p);

        assertEquals(Grass.class, map.tiles[p.x][p.y].getClass());
    }
    @Test
    public void testDemolish2() {
        Point p = new Point(1, 1);
        map.setBuilding(new Stadium(p, 0), p);
        p = new Point(2, 2);
        map.demolish(p);

        assertEquals(Grass.class, map.tiles[p.x][p.y].getClass());
        assertEquals(Grass.class, map.tiles[p.x+1][p.y].getClass());
        assertEquals(Grass.class, map.tiles[p.x][p.y+1].getClass());
        assertEquals(Grass.class, map.tiles[p.x+1][p.y+1].getClass());
    }

    @Test
    public void testDemolish3() {
        Point p = new Point(map.tiles.length / 2 - 1, map.tiles[0].length - 1);
        map.tiles[p.x][p.y] = new Road(p);
        map.demolish(p);

        assertEquals(Road.class, map.tiles[p.x][p.y].getClass());
    }
}
