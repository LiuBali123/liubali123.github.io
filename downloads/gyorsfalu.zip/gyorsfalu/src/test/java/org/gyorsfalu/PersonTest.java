package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
public class PersonTest extends TestCase {
    Map map;
    Person person;
    @Before
    public void setUp() {
        map = new Map();
        map.newMap();
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                map.tiles[i][j] = new Grass();
            }
        }
        Point p = new Point(1,1);
        Zone home = new Zone(p, ZoneType.RESIDENTIAL);
        home.building.maxCapacity = 1;
        map.setBuilding(home, p);
        p = new Point(1,3);
        Zone work = new Zone(p, ZoneType.SERVICES);
        work.building.maxCapacity = 1;
        map.setBuilding(work, p);
        p = new Point(1,2);
        map.setBuilding(new Road(p), p);
        person = new Person(home.building, work.building, 20);
        home.addPerson(person);
        work.addPerson(person);
    }

    @Test
    public void testSatisfaction() {
        double pastStat = person.satisfaction;
        person.home.isSafe = true;
        person.calcSat();
        assertEquals((int)pastStat + 5,(int)person.getSatisfaction());
    }

    @Test
    public void testSatisfaction2() {
        double pastStat = person.satisfaction;
        person.home.isSafe = false;
        person.safeHome = true;
        person.calcSat();
        assertEquals((int)pastStat - 5,(int)person.getSatisfaction());
    }

    @Test
    public void testUnlink() {
        Zone home = person.home.zone;
        Zone work = person.workplace.zone;
        person.unlink();
        assertEquals(0,home.building.residents.size());
        assertEquals(0,work.building.residents.size());
    }

    @Test
    public void testUnlink2() {
        Zone home = person.home.zone;
        Zone work = person.workplace.zone;
        person.workplace.zone = null;
        person.unlink();
        assertEquals(0,home.building.residents.size());
        assertEquals(0,work.building.residents.size());
    }
}
