package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;

public class PlayerBuildTest extends TestCase {
    Map map;
    PlayerBuild build;
    @Before
    public void setUp() {
        map = new Map();
        map.newMap();
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                map.tiles[i][j] = new Grass();
            }
        }
        Point p = new Point(1,1);
        build = new Zone(p, ZoneType.RESIDENTIAL);
        map.tiles[p.x][p.y] = build;
        build.tiles = map.tiles;
    }
    @Test
    public void testPutOutFire() {
        ArrayList<Fireman> firemen = new ArrayList<>();
        build.setOnFire();
        Fireman fireman = new Fireman(0, new Point(1, 2));
        firemen.add(fireman);
        build.putOutFire(firemen);
        assertFalse(build.isOnFire);
    }
    @Test
    public void testPutOutFire2() {
        ArrayList<Fireman> firemen = new ArrayList<>();
        build.setOnFire();
        Fireman fireman = new Fireman(0, new Point(1, 3));
        firemen.add(fireman);
        build.putOutFire(firemen);
        assertTrue(build.isOnFire);
    }
    @Test
    public void testIsPlaceable() {
        assertFalse(build.isPlaceable(new Point(1, 1), map));
    }
    @Test
    public void testIsPlaceable2() {
        assertFalse(build.isPlaceable(new Point(1, 5), map));
    }
    @Test
    public void testIsPlaceable3() {
        Point point = new Point(1, 4);
        map.tiles[point.x][point.y] = new Road(point);
        assertTrue(build.isPlaceable(new Point(1, 5), map));
    }
}
