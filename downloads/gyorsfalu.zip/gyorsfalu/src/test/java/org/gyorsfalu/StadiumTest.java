package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class StadiumTest extends TestCase {

    Map map;
    Stadium stadium;
    @Before
    public void setUp() {
        map = new Map();
        map.newMap();
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                map.tiles[i][j] = new Grass();
            }
        }
        Point p = new Point(1,1);
        stadium = new Stadium(p, 0);
        map.setBuilding(stadium, p);
    }

    @Test
    public void testIsPlaceable(){
        Point bad = new Point(map.tiles.length -1 , map.tiles[0].length -1);
        assertFalse(stadium.isPlaceable(bad,map));
    }

    @Test
    public void testIsPlaceable2(){
        Point good = new Point(5, 5);
        map.setBuilding(new Zone(good, ZoneType.RESIDENTIAL), good);
        assertFalse(stadium.isPlaceable(good,map));
    }

    @Test
    public void testIsPlaceable3(){
        Point good = new Point(5, 5);
        map.setBuilding(new Road(new Point(5, 7)), new Point(5, 7));
        assertTrue(stadium.isPlaceable(good,map));
    }

}
