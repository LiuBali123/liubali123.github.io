package org.gyorsfalu;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;

public class ZoneTest extends TestCase {

    Map map;
    Zone zone;
    Point p;
    @Before
    public void setUp() {
        map = new Map();
        map.newMap();
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                map.tiles[i][j] = new Grass();
            }
        }
        p = new Point(1,1);
        zone = new Zone(p, ZoneType.RESIDENTIAL);
        map.tiles[p.x][p.y] = zone;
    }
    @Test
    public void testLevelUp(){
        Budget budget = new Budget(1000);
        zone.level = 0;
        zone.levelup(budget);
        assertEquals(1, zone.level);
        assertEquals(950, budget.getCurrentMoney());
    }
    @Test
    public void testLevelUp2(){
        Budget budget = new Budget(1000);
        zone.level = -1;
        zone.levelup(budget);
        assertEquals(1, zone.level);
        assertEquals(800, budget.getCurrentMoney());
    }
    @Test
    public void testLevelUp3(){
        Budget budget = new Budget(1000);
        zone.level = 3;
        zone.levelup(budget);
        assertEquals(3, zone.level);
        assertEquals(1000, budget.getCurrentMoney());
    }
    @Test
    public void testDemolish(){
        zone.demolish(p, map);
        assertEquals(Grass.class, map.tiles[p.x][p.y].getClass());
    }
    @Test
    public void testDemolish2(){
        Zone work = new Zone(p, ZoneType.SERVICES);
        work.addPerson(new Person(zone.building, work.building, 20));
        work.demolish(p, map);
        assertNull(work.building.residents.get(0).workplace);
    }
}
