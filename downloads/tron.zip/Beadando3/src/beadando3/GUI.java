/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author Balint
 */
public class GUI {

    private JFrame frame;
    private GameEngine gameArea;
    private boolean gameStarted;

    /**
     * Creates GUI
     * @throws SQLException 
     */
    public GUI() throws SQLException {
        gameStarted = false;
        frame = new JFrame("Tron");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);
        JMenu gameMenu = new JMenu("Game");
        menuBar.add(gameMenu);
        JMenuItem newMenu = new JMenuItem("New");
        gameMenu.add(newMenu);
        JMenuItem topMenu = new JMenuItem("Highscores");
        gameMenu.add(topMenu);

        HighScores highScores = new HighScores(10);

        newMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] colors = {"blue", "green", "purple"};
                String p1 = null;
                while (p1 == null || p1.equals("")) {
                    p1 = JOptionPane.showInputDialog(frame, "Player1 name:");
                }
                String c1 = null;
                while(c1 == null){
                    c1 = (String) JOptionPane.showInputDialog(frame, "Player1 color:", "Input", JOptionPane.QUESTION_MESSAGE, null, colors, colors[0]);
                }
                ArrayList<String> temp = new ArrayList<>(Arrays.asList(colors));
                temp.remove(c1);
                colors = temp.toArray(String[]::new);

                
                String p2 = null;
                while (p2 == null || p2.equals("")) {
                    p2 = JOptionPane.showInputDialog(frame, "Player2 name:");
                }
                String c2 = null;
                while(c2 == null){
                    c2 = (String) JOptionPane.showInputDialog(frame, "Player2 color:", "Input", JOptionPane.QUESTION_MESSAGE, null, colors, colors[0]);
                }
                gameArea.setPlayer1_name(p1);
                gameArea.setPlayer2_name(p2);
                gameArea.setPlayer1_color(c1);
                gameArea.setPlayer2_color(c2);
                gameArea.start();
            }
        });

        topMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!gameArea.isPaused()){
                    gameArea.pause();
                }
                try {
                    new HighScoreWindow(highScores.getHighScores(), frame);
                    //highScores.getHighScores()
                } catch (SQLException ex) {
                    Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        gameArea = new GameEngine();
        frame.getContentPane().add(gameArea,BorderLayout.CENTER);
        frame.getContentPane().add(gameArea.getTimeLabel(),BorderLayout.SOUTH);
        frame.setPreferredSize(new Dimension(894 + 5, 475 + 10));
        frame.setResizable(false);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
