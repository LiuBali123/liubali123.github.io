/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;

/**
 *
 * @author Balint
 */
public class GameEngine extends JPanel {

    private final int FPS = 120;
    private final double MOVEMENT = 0.7;
    private final int PLAYER1_X = 235;
    private final int PLAYER1_Y = 100;
    private final int PLAYER2_X = 659 - 40;
    private final int PLAYER2_Y = 100;
    private final int PLAYER_WIDTH = 27;//68
    private final int PLAYER_HEIGHT = 70;//175
    private final int LINE_LENGHT = 700;

    private boolean paused = false;
    private Image background;
    private boolean started;

    private Player player1;
    private Player player2;
    private String player1_name;
    private String player2_name;
    private String player1_color;
    private String player2_color;

    private JLabel timeLabel;
    private Timer newFrameTimer;
    private Timer timer;
    private long startTime;
    private long pausedTime;
    private int negativetime;

    /**
     * Creates the game: maps the keys and creates a timer
     */
    public GameEngine() {
        super();
        started = false;
        background = new ImageIcon("data/images/background.jpg").getImage();

        //player1 keys
        this.getInputMap().put(KeyStroke.getKeyStroke("A"), "pressed a");
        this.getActionMap().put("pressed a", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player1, "left");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("D"), "pressed d");
        this.getActionMap().put("pressed d", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player1, "right");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("S"), "pressed s");
        this.getActionMap().put("pressed s", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player1, "down");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("W"), "pressed w");
        this.getActionMap().put("pressed w", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player1, "up");
            }
        });

        //player2 keys
        this.getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "pressed left");
        this.getActionMap().put("pressed left", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player2, "left");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "pressed right");
        this.getActionMap().put("pressed right", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player2, "right");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "pressed down");
        this.getActionMap().put("pressed down", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player2, "down");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("UP"), "pressed up");
        this.getActionMap().put("pressed up", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                changedirection(player2, "up");
            }
        });
        this.getInputMap().put(KeyStroke.getKeyStroke("ESCAPE"), "escape");
        this.getActionMap().put("escape", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pause();
            }
        });

        timeLabel = new JLabel(" ");
        timeLabel.setHorizontalAlignment(JLabel.RIGHT);
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeLabel.setText(elapsedTime() + " ms");
            }
        });
        newFrameTimer = new Timer(1000 / FPS, new NewFrameListener());
    }
    
    /**
     * Starts the game and the timer
     */
    public void start() {
        restart();
        newFrameTimer.start();
        startTime = System.currentTimeMillis();
        pausedTime = System.currentTimeMillis();
        started = true;
        paused = false;
        negativetime = 0;
        startTime = System.currentTimeMillis();
        timer.start();
    }

    /**
     * Used to create new players
     */
    public void restart() {
        Image player1_image = new ImageIcon("data/images/" + player1_color + "down.png").getImage();
        Image player2_image = new ImageIcon("data/images/" + player2_color + "down.png").getImage();
        player1 = new Player(player1_name, (double) PLAYER1_X, (double) PLAYER1_Y, PLAYER_WIDTH, PLAYER_HEIGHT, player1_image, MOVEMENT, player1_color);
        player2 = new Player(player2_name, (double) PLAYER2_X, (double) PLAYER2_Y, PLAYER_WIDTH, PLAYER_HEIGHT, player2_image, MOVEMENT, player2_color);
    }

    @Override
    protected void paintComponent(Graphics grphcs) {
        super.paintComponent(grphcs);
        grphcs.drawImage(background, 0, 0, 894, 475, null);
        if (started) {
            player1.draw(grphcs);
            player2.draw(grphcs);
        }
    }

    /**
     * Changes the given player's direction to dir if it is allowed
     * @param p player
     * @param dir direction to change to
     */
    public void changedirection(Player p, String dir) {
        if ((p.getDirection().equals(dir)) || p.opposite(dir)) {
            return;
        }
        p.switchSize();
        if (p.getDirection().equals("down")) {
            if (dir.equals("right")) {
                p.setVelx(MOVEMENT);
                p.setVely(0);
            }
            if (dir.equals("left")) {
                p.setVelx(-MOVEMENT);
                p.setVely(0);
                p.setX(p.getX() - p.getWidth() + p.getHeight());
            }
        }
        if (p.getDirection().equals("left")) {
            if (dir.equals("up")) {
                p.setVely(-MOVEMENT);
                p.setVelx(0);
                p.setX(p.getX() - p.getWidth() + p.getHeight());
                p.setY(p.getY() + p.getWidth() - p.getHeight());
            }
            if (dir.equals("down")) {
                p.setVely(MOVEMENT);
                p.setVelx(0);
                p.setX(p.getX() - p.getWidth() + p.getHeight());
            }
        }
        if (p.getDirection().equals("up")) {
            if (dir.equals("right")) {
                p.setVelx(MOVEMENT);
                p.setVely(0);
                p.setY(p.getY() + p.getWidth() - p.getHeight());
            }
            if (dir.equals("left")) {
                p.setVelx(-MOVEMENT);
                p.setVely(0);
                p.setX(p.getX() - p.getWidth() + p.getHeight());
                p.setY(p.getY() + p.getWidth() - p.getHeight());
            }
        }
        if (p.getDirection().equals("right")) {
            if (dir.equals("up")) {
                p.setVely(-MOVEMENT);
                p.setVelx(0);
                p.setY(p.getY() + p.getWidth() - p.getHeight());
            }
            if (dir.equals("down")) {
                p.setVely(MOVEMENT);
                p.setVelx(0);
            }
        }
        Image image = new ImageIcon("data/images/" + p.getColor() + dir + ".png").getImage();
        p.setImage(image);
        p.setDirection(dir);
    }

    /**
     * Pauses the game
     */
    public void pause() {
        if (!paused) {
            pausedTime = System.currentTimeMillis();
            timer.stop();
        } else {
            negativetime += System.currentTimeMillis() - pausedTime;
            timer.start();
        }
        paused = !paused;
    }

    /**
     * Moves the players and checks if someone won
     */
    class NewFrameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            boolean player1lost = false;
            boolean player2lost = false;
            if (!paused && started) {
                player1lost = player1.move();
                player2lost = player2.move();
                if (player1.collidesLine(player2.getLine())) {
                    player1lost = true;
                }
                if (player1.collidesLine(player1.getLine())) {
                    player1lost = true;
                }
                if (player2.collidesLine(player1.getLine())) {
                    player2lost = true;
                }
                if (player2.collidesLine(player2.getLine())) {
                    player2lost = true;
                }
                player1.addLinepart();
                player2.addLinepart();
                player1.move();
                player2.move();
                if (player1.getLine().getLineparts().size() == LINE_LENGHT) {
                    player1.getLine().removeLinepart();
                    player2.getLine().removeLinepart();
                }
            }
            if (player1lost) {
                gameOver(player2);
            } else if (player2lost) {
                gameOver(player1);
            }
            repaint();
        }

    }

    /**
     * Stops the game and records the score if it is good enough
     * @param winner 
     */
    public void gameOver(Player winner) {
        pause();
        try {
            HighScores highScores = new HighScores(10);
            highScores.putHighScore(winner.getName(), (int)elapsedTime());
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * return the elapsed time since the game started
     * @return 
     */
    public long elapsedTime() {
        return System.currentTimeMillis() - startTime - negativetime;
    }

    public void setPlayer1_name(String player1_name) {
        this.player1_name = player1_name;
    }

    public void setPlayer2_name(String player2_name) {
        this.player2_name = player2_name;
    }

    public void setPlayer1_color(String player1_color) {
        this.player1_color = player1_color;
    }

    public void setPlayer2_color(String player2_color) {
        this.player2_color = player2_color;
    }

    public boolean isPaused() {
        return paused;
    }

    public JLabel getTimeLabel() {
        return timeLabel;
    }
}
//JOptionPane.showMessageDialog(boardPanel, "You have won in " + (model.getSteps() + 1) + " steps.", "Congrats!", JOptionPane.PLAIN_MESSAGE);
