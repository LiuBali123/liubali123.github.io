/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beadando3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Properties;

/**
 *
 * @author bli
 */
public class HighScores {

    int maxScores;
    PreparedStatement insertStatement;
    PreparedStatement deleteStatement;
    Connection connection;

    public HighScores(int maxScores) throws SQLException {
        this.maxScores = maxScores;
        Properties connectionProps = new Properties();
        // Add new user -> MySQL workbench (Menu: Server / Users and priviliges)
        //                             Tab: Administrative roles -> Check "DBA" option
        connectionProps.put("user", "tron");
        connectionProps.put("password", "tron");
        connectionProps.put("serverTimezone", "UTC");
        String dbURL = "jdbc:mysql://localhost:3306/highscores";
        connection = DriverManager.getConnection(dbURL, connectionProps);

        String insertQuery = "INSERT INTO HIGHSCORES (NAME, TIME) VALUES (?, ?)";
        insertStatement = connection.prepareStatement(insertQuery);
        String deleteQuery = "DELETE FROM HIGHSCORES WHERE TIME=?";
        deleteStatement = connection.prepareStatement(deleteQuery);
    }

    /**
     * Return an ArrayList with all the High scores
     * @return
     * @throws SQLException 
     */
    public ArrayList<HighScore> getHighScores() throws SQLException {
        String query = "SELECT * FROM HIGHSCORES";
        ArrayList<HighScore> highScores = new ArrayList<>();
        Statement stmt = connection.createStatement();
        ResultSet results = stmt.executeQuery(query);
        while (results.next()) {
            String name = results.getString("NAME");
            int time = results.getInt("TIME");
            highScores.add(new HighScore(name, time));
        }
        sortHighScores(highScores);
        return highScores;
    }

    /**
     * Checks if it is possible to put the score in the database
     * @param name Name of player
     * @param time Time of the game
     * @throws SQLException 
     */
    public void putHighScore(String name, int time) throws SQLException {
        ArrayList<HighScore> highScores = getHighScores();
        if (highScores.size() < maxScores) {
            insertScore(name, time);
        } else {
            int longestTime = highScores.get(highScores.size() - 1).getTime();
            if (longestTime > time) {
                deleteScores(longestTime);
                insertScore(name, time);
            }
        }
    }

    /**
     * Sort the high scores in descending order.
     * Less time = Better score
     * @param highScores
     */
    private void sortHighScores(ArrayList<HighScore> highScores) {
        Collections.sort(highScores, new Comparator<HighScore>() {
            @Override
            public int compare(HighScore t, HighScore t1) {
                return t.getTime() - t1.getTime();
            }
        });
    }
    
    /**
     * Puts a high score into the database
     * @param name Name of player
     * @param time Time of the game
     * @throws SQLException 
     */
    private void insertScore(String name, int time) throws SQLException {
        //Timestamp ts = new Timestamp(System.currentTimeMillis());
        insertStatement.setString(1, name);
        insertStatement.setInt(2, time);
        //insertStatement.setInt(3, score);
        insertStatement.executeUpdate();
    }

    /**
     * Deletes all the highscores with time.
     *
     * @param time
     */
    private void deleteScores(int time) throws SQLException {
        deleteStatement.setInt(1, time);
        deleteStatement.executeUpdate();
    }
}
