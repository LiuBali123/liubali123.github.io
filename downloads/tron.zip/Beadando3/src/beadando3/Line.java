/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Balint
 */
public class Line{
    private final double LINESIZE = 10;
    
    private ArrayList<Linepart> parts;
    private Player player;
    
    public Line(Player player) {
        parts = new ArrayList<>();
        this.player = player;
    }
    
    /**
     * Draws all the LineParts
     * @param g 
     */
    public void draw(Graphics g){
        for(Linepart part : parts){
            part.draw(g);
        }
    }
    
    /**
     * Adds part to the line
     * @param part 
     */
    public void addLinepart(Linepart part){
        this.parts.add(part);
    }
    
    /**
     * Removes the oldest part of the line
     */
    public void removeLinepart(){
        this.parts.remove(0);
    }
    public ArrayList<Linepart> getLineparts(){
        return this.parts;
    }

    public Player getPlayer() {
        return player;
    }
    
    @Override
    public String toString(){
        String temp = "";
        for(Linepart part : parts){
            temp+= part.toString();
        }
        return temp;
    }

    public double getLINESIZE() {
        return LINESIZE;
    }
    
}
