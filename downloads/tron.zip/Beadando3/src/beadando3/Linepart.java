/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.Image;

/**
 *
 * @author Balint
 */
public class Linepart extends Sprite{
    private Player player;
    
    public Linepart(double x, double y, int width, int height, Image image, Player player) {
        super(x, y, width, height, image);
        this.player = player;
    }
    
    @Override
    public String toString(){
        return "(" + x + " " + y + ")";
    }
}
