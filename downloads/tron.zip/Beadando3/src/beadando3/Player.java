/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author Balint
 */
public class Player extends Sprite {

    private final int BORDER = 50;

    private String name;
    private Line line;
    private double velx;
    private double vely;
    private String direction;
    private String color;

    public Player(String name, double x, double y, int width, int height, Image image, double vely, String color) {
        super(x, y, width, height, image);
        this.velx = 0;
        this.vely = vely;
        this.name = name;
        this.line = new Line(this);
        this.direction = "down";
        this.color = color;
    }

    /**
     * Moves the player by adding the velocity to the coordinates
     * @return true if the player is out of the map
     */ 
    public boolean move() {
        x += velx;
        y += vely;
        return (x < 0 || x + width + 15 > 894 || y < 0 || y + height + 69 > 475);
    }

    @Override
    public void draw(Graphics g) {
        g.drawImage(image, (int) x, (int) y, width, height, null);
        line.draw(g);
    }

    public String getName() {
        return name;
    }

    public void setVelx(double velx) {
        this.velx = velx;
    }

    public void setVely(double vely) {
        this.vely = vely;
    }

    public double getVelx() {
        return velx;
    }

    public double getVely() {
        return vely;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    /**
     * Switches the height with the width, used when turning
     */
    public void switchSize() {
        int temp = this.height;
        this.height = this.width;
        this.width = temp;
    }

    /**
     * Return true when the player collides with a player's line
     * @param line
     * @return 
     */
    public boolean collidesLine(Line line) {
        ArrayList<Linepart> parts = line.getLineparts();
        for (int i = 0; i < parts.size(); i++) {
            if (parts.get(i).collides(this)) {
                if ((line.getPlayer() == this) && (parts.size() - i > BORDER)) {
                    return true;
                } else if (line.getPlayer() != this) {
                    return true;
                }
            }
        }
        return false;
    }

    public Line getLine() {
        return line;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
    
    /**
     * Return true when dir is the opposite direction of the player, used when turning
     * @param dir
     * @return 
     */
    public boolean opposite(String dir) {
        return ((this.direction.equals("down") && dir.equals("up"))
                || (this.direction.equals("up") && dir.equals("down"))
                || (this.direction.equals("left") && dir.equals("right"))
                || (this.direction.equals("right") && dir.equals("left")));
    }

    public String getColor() {
        return color;
    }

    /**
     * Adds a part to the line
     */
    public void addLinepart() {
        Image colori = new ImageIcon("data/images/" + color + ".png").getImage();
        double size = line.getLINESIZE();
        double tempx = 0;
        double tempy = 0;
        if (this.direction.equals("down")) {
            tempx = (this.x + this.width/2 - size/2);
            tempy = (this.y + this.width/2 - size/2);
        }else if(this.direction.equals("right")){
            tempx = (this.x + this.height/2 - size/2);
            tempy = (this.y + this.height/2 - size/2);
        }else if(this.direction.equals("up")){
            tempx = (this.x + this.width/2 - size/2);
            tempy = (this.y + this.height-this.width/2 - size/2);
        }else if(this.direction.equals("left")){
            tempx = (this.x + this.width-this.height/2 - size/2);
            tempy = (this.y + this.height/2 - size/2);
        }
        line.addLinepart(new Linepart(tempx, tempy, (int)size, (int)size, colori, this));
    }
}
