/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beadando3;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

/**
 * 
 * @author Balint
 */
public class Sprite {
    /**
     * The coordinates of the top left corner of the sprite
     */
    protected double x;
    protected double y;
    protected int width;
    protected int height;
    protected Image image;

    public Sprite(double x, double y, int width, int height, Image image) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
    }
    
    /**
     * Draws the sprite
     */
    public void draw(Graphics g) {
        g.drawImage(image, (int)x, (int)y, width, height, null);
    }
    
    /**
     * Returns true if this sprite collides with the other sprite
     * @param other
     * @return 
     */
    public boolean collides(Sprite other) {
        Rectangle rect = new Rectangle((int)x, (int)y, width, height);
        Rectangle otherRect = new Rectangle((int)other.x, (int)other.y, other.width, other.height);        
        return rect.intersects(otherRect);
    }

    public int getX() {
        return (int)x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public int getY() {
        return (int)y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
